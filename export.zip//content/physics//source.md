---
title: Physics
slug: physics
parent_slug: 
path: physics/
---

Physics is the natural science that involves the study of matter and its motion and behavior through space and time, along with related concepts such as energy and force. [Wikipedia](https://en.wikipedia.org/wiki/Physics)

### Old questions

* [Physics New Course Grade 11 - 2069 (2012)](http://www.scribd.com/doc/100293603/HSEB-Question-Collection-Series-Physics-New-Course-2069-XI-HSEB-NOTES)

