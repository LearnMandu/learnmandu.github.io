---
title: Huygen's Principle
slug: huygens-principle
parent_slug: physics
path: physics/huygens-principle/
---

 Huygen’s Principle is a geometrical construction which was designed to determine the position, shape and the size of a wavefront in future if its present position and nature is known.

    In 1678, Huygens proposed that every point to which a luminous disturbance reaches becomes a source of a spherical wave; the sum of these secondary waves determines the form of the wave at any subsequent time. He assumed that the secondary waves travelled only in the "forward" direction and it is not explained in the theory why this is the case. He was able to provide a qualitative explanation of linear and spherical wave propagation, and to derive the laws of reflection and refraction using this principle, but could not explain the deviations from rectilinear propagation which occur when light encounters edges, apertures and screens, commonly known as diffraction effects.  Wikipedia

Statement

* Each point or particle on the primary wavefront acts as a source of light for secondary wavefronts, which sends out disturbance (waves) in all direction in the similar manner as the original source of light does.

* The new position of wave front at any instant of time is given by the forward envelope of second wavelets at that instant.

![Alt](http://2.bp.blogspot.com/-2zI8-GuSNxs/UAP-yioikAI/AAAAAAAAATk/DWQQGOM5GxY/s200/huygen-principle-for-propagation-of-light-as-wavefront-and-wavelets-hseb-notes.jpg "Title")

 Explanation:
Let us consider a source of light S. which sends out disturbance (wave) in all direction. Let, one of the disturbance be AB which is at distance r = c×t from the sources where,

    c = velocity of light
    t = time to reach at AB

Then, from Huygen’s first principle, each point on the primary wavefront acts as a source of light which sends out disturbance in all direction and such disturbance is called secondary wavefront.

Similarly, from Huygen’s second principle, the new position of wavefront A¹B¹ s given by the forward envelope of secondary wavelet or a tangent line on collecting all the secondary wavelets, gives the position of secondary wavefront having radius equal to c(t+Δt) from the source i.e. r¹=c(t+Δt). In this way wave propagates from one point to another point.
