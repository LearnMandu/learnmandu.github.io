---
title:  Stress and Strain Curve 
slug: stress-and-strain-curve
parent_slug: physics
path: physics/stress-and-strain-curve/
---

 Stress strain (curve):

The diagram shows the stress-strain curve for a ductile material. From the first part OA it is clear that Stress ∝ Strain. So, up to the point A, known as proportionality limit, Hooke’s law is obeyed. On further increase in stress, strain also increases but they are not increased proportionally. If the wire is unloaded up to the point B, it regains it’s original shape and size, so the point B is known as elastic limit or yelled point.

![Alt](http://4.bp.blogspot.com/-6INunjsPOkI/UA0pY111VAI/AAAAAAAAAWY/hOHQlHsXx9k/s1600/Stress-strain-curve.jpg "Curve")

Beyond B if the stress is increased the strain increases largely, if the wire is unloaded it doesn’t regains it’s original form, i.e. the curve retraces from C to O1 showing permanent set. And body shows the plastic behavior. On further increase in stress, the strain produces largely upto the point E at which stress is said to be breaking stress. Beyond E even a stress is decreased, the strain is increased and finally at D known as fracture point the wire is fractured.

From O to B the body undergoes plastic deformation which forms B to D, it undergoes plastic deformation. If the plastic deformation from elastic limit B and fracture point D is large then the body is said to be ductile if it is small the body is britile.

