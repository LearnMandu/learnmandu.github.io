---
title: Important Questions and Solutions for Physics
slug: important-questions
parent_slug: physics
path: physics/important-questions/
---

1. [Heat and Thermodynamics](https://drive.google.com/file/d/0B7gXFbMQlOIPMi05NTFvbmh4dzQ/view)
