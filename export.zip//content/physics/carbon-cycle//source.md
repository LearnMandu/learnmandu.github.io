---
title: Carbon Cycle 
slug: carbon-cycle
parent_slug: physics
path: physics/carbon-cycle/
---

 Carbon is the basic constituents of all organic compounds. The source of carbon found in the living organism is atmospheric carbon dioxide (CO2), which is found in Free State in atmosphere and in dissolved state in water. Green plants are autotrophic, which use carbon dioxide through photosynthesis in the presence of sun light and carbohydrate is formed. When herbivorous animal consume the green plants, the carbon compound contained in the plant will be turned into other carbonic compound. 


Further degradation of those carbonic compound will occur when carnivorous animal consume those herbivorous animal. Carbon is released to the atmosphere directly as CO2 in respiration of both plants and animals. They degrade the complex organic compounds into the simpler form, which are then available for other cycles. In this way carbon moves on the ecosystem with the flow of energy and known as carbon cycle. Some forms of the organic compounds found in the earth’s crust are coal, gas, petroleum, limestone, etc.

![Alt](http://4.bp.blogspot.com/-L7LEhrMjojI/UAUvx9aJHmI/AAAAAAAAAUc/_IXLDapSEXo/s1600/carbon-cycle-figure.jpg "title")
