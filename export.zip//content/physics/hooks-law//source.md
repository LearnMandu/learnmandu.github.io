---
title:  Hooke's Law and Its Experimental Verification 
slug: hooks-law
parent_slug: physics
path: physics/hooks-law/
---

 Robert Hooke performed an experiment on coiled spring, metallic rod or metallic wires etc and gave a law known as Hooke's law. It states that, "The restoring force developed on a body is directly proportional to the elongation produced on it, within the elastic limit."
      i.e. F∝x
      ∴F=-Kx       [Where K is proportionality constant.]

Young modified Hooke's statement and stated as, "Within elastic limit, the stress developed on the body is directly proportional to the strain produced on it."
i.e. Stress ∝ Strain
Or, Stress = Constant × Strain
∴ Stress ÷ Strain = E

Where, E is proportionality constant known as modulus of elasticity. Its unit is N/m2 or Pa. Its value depends upon the material and type of deformation produced on the body.

Experimental Verification of Hooke’s Law
Consider two identical metallic wires A and B on which main scale and vernier scales are fixed and the wires are suspended from rigid support.
The kinks produced on the reference wire A and experimental wire B are removed by loading weight at their free ends known as dead loads with the help of meter scale length l at wire B is measured and with the help of micrometer screw gauge its radius r is also measured.

Now, main scale reading and vernier scale readings are noted. The equal loads are added on the pan of wire B and corresponding reading are noted. Let, w1, w2, w3 and w4 be the weights on the wire B and e1, e2, e3 and e4 are corresponding elongations produced, within elastic limit.

![Alt](http://3.bp.blogspot.com/-iXmDLBAQWKc/UA0EazPRZtI/AAAAAAAAAVk/HZDDR2O9Ieg/s1600/mathematic-expressions-of-expreimental-verification-of-hooke%27s-law.jpg "Title")

 Also, if a graph is plotted between weight F and elongation e, a straight line passing through the origin is obtained whose slope is constant, which verifies Hooke’s law.

Point to remember: Stress measures deforming force whereas strain measures deformation.
