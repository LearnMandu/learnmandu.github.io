---
title:  Millikan's Oil Drop Experiment 
slug: millikans-oil-drop-experiment
parent_slug: physics
path: physics/millikans-oil-drop-experiment/
---


When a spherical charged body of radius r falls under the effect of various forces in a viscous medium of viscocity η, it attends the terminal velocity vt when the viscous force becomes 6πηrvt (Stoke’s law)

Experimental setup and Theory: An experimental setup of Millikan’s experiment to determine the change in oil drop is shown in figure. At first, clock oil (non volatile) is allowed to fall drop wise from the opening of upper plate A with the help of atomizer. This law undergoes collision with air particles and gets charged. The whole apparatus is kept inside double walled chamber inside which water is circulated for cooling purpose. The chamber consists of 2 windows.

W1: To pass visible light and W2: To pass X-ray (to ionize the oil drop)

The upper plate A is connected with positive terminal of battery and lower plate B is earthed. 

![Alt](http://2.bp.blogspot.com/-Rmvp57BgnOg/UA0J9PxViXI/AAAAAAAAAVw/SO7iHOg94I0/s320/millikan%27s-apparatus-millikan%27s-oil-drop-experiment.jpg "Title")

 The experiment is performed in two steps.

Step 1 (Electric field is switched off): At this condition, at equilibrium, the drop experiences following forces,


![Alt](http://2.bp.blogspot.com/-c87_ZiDtFQM/UA0KnROwJ_I/AAAAAAAAAV4/dCWhiG1b9iQ/s1600/millikan%27s-oil-drop-experiment-without-electric-field-equation.jpg "Title")

 Let, v1 be the terminal velocity of drop then according to Stoke’s law, viscous force F1=6πηrv1

When drop attends terminal velocity, we have,

![Alt](http://3.bp.blogspot.com/-wXwCzGfwivk/UA0LWL_Ck-I/AAAAAAAAAWA/X7Ht7fu9YPE/s1600/millikan%27s-oil-drop-experiment-without-electric-field-equation2.jpg "Title")


This is the required expression for the radius of the oil drop.

Step 2 (Electric Field is Applied):
Now, let us apply the electric field between two plates A and B in such a way that (-ve) charged oil drop moves upward and gains terminal velocity v2. Let q be the charge in the drop and E be the electric field intensity.

When the drop attends uniform velocity we have,

![Alt](http://3.bp.blogspot.com/-IvnjohLShVc/UA0LmnspvJI/AAAAAAAAAWI/g9HekagGiI8/s320/millikan%27s-oil-drop-experiment-with-electric-field-equation.jpg "Title")


This is the required expression for charge produced in the drop. Thus knowing η,v1,v2, ρ, σ,g, V, d value of q can be determined.

The experiment was performed by taking oils of different sizes and concluded that the charge produced in any drop is always an integral multiple of basic electronic charge e=1.6×10-19 i.e. q=nE

This is also called quantization of charge.
