---
title:  The Nitrogen Cycle 
slug: nitrogen-cycle
parent_slug: physics
path: physics/nitrogen-cycle/
---

 Plant absorb greatest quality of nitrogen from the soil for the synthesis of amino acid, protein, enzymes, nucleic acid, chlorophyll, etc. the main source of nitrogen compound is the atmospheric nitrogen. Nitrogen cycle consists of the following steps:

Nitrogen fixation: Conversion of atmospheric nitrogen into free nitrogen is referred as nitrogen fixation. This process is of two types a)Non-biological nitrogen fixation and b) Biological nitrogen fixation

      a) Non-Biological nitrogen fixation: Nitrogen combines with oxygen during lightening or electric discharge in the cloud. These nitrogen oxides get dissolved in rain water.

      b) Biological nitrogen fixation: it is carried out by certain blue green algae, bacterial etc. Rhizobium inhibeting the root modules of legumes fix atmospheric nitrogen into free nitrogen.

Nitrogen Assimilation: Inorganic nitrogen in the form of nitrates, nitrites and ammonia is absorbed by the green plants and converted into nitrogenous organic compound.

Ammonification: The dead organic remains of plants and animal and excreta of animals are acted upon by a number of micro-organism. These organisms utilize organic compound in their metabolism and release ammonia.

Nitrification: Certain bacteria in ocean and soil convert ammonia into nitrites and nitrites into nitrates.

Denitrification: Ammonia and nitrates are converted into free nitrogen by certain microbes. This process is referred as denitrification.

Sedimentation: Nitrates of soils are washed away to the sea or deep into the earth along with percolating water. Nitrates thus from the soil surface are locked up in the rock. This is sedimentation of nitrogen. 

![Alt](http://4.bp.blogspot.com/-ImcKXWNYSTo/UAU11stWAtI/AAAAAAAAAU8/ot3dYrUD6TU/s640/nitrogen-cycle-diagram.jpg "Title")
