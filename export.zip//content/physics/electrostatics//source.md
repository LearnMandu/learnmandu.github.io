---
title: Electrostatics 
slug: electrostatics
parent_slug: physics
path: physics/electrostatics/
---

 An atom is electrically neutral. Why?
Electrons moves round a positively charged nucleus. Nucleus contains as many positively charged protons as there are electrons. The charge carried by an electron and proton are equal in magnitude and opposite in sign. Hence atom as a whole is neutral.

Explain why the induced charges are not always equal to inducing charge in magnitude?
The charge induced on an insulator is always less than inducing charge in magnitude as the insulator has bound charges while charge induced on conductor equals to the inducing charge in magnitude.


Why the positively charged rod does attract paper pieces which are uncharged?
When a positively charged rod is brought close to uncharged paper pieces, due to induction, negative charge is developed at near end and positive at remote end.
Let Fa=force of attraction between positively charged rod and induced negative charge at remote end of paper piece.

As Fa>Fr this result in attraction of the paper pieces towards the positively charged rod.

The vehicles carrying inflammable materials usually have metallic chain touching the ground. Why?
Due to friction, the tires and the body both may get charged. If the charge accumulation is large, there may occur sparking and may cause a fire on inflammable material. If the tires drag a metal chain on the ground, the charges leak to the ground and sparking is avoided.

Can two similarly charged balls attract each other?
Yes, when charge on one, say A is much larger than the charge on the other, say B on account of induction, the ball B carrying smaller charge shall acquire some charge of opposite sign lying closer to A. Hence, B will experience some net force of attraction.

Can electric potential exist at a region where the electric field has zero value? Give example to illustrate your answer.
Yes, electric potential exists at a point though the field is zero.
Let P be point that lies mid way between two equal positive charges q1 and q2. At the point P, fields due to two charges cancel each other but resulting potential at P is twice the potential due to each charge. The electric field intensity inside a charged conducting sphere is zero but potential at any point inside the charged sphere is same as the potential on its surface.

Why sharp points or edges avoided in electrical machine?
Leakage of charges from the sharp points or edges of conductor occurs due to dielectric breakdown in air duce to high electric field at the sharp points or edges. That’s why edges are avoided in electric machines.

Why can more charge be stored on highly polished metal sphere than in rough surface?
Discharging action of sharp points in the conductor discharges the conductor i.e. loss of charges from the sharp points of conductor. To hold a charge in the conductor in air, its surface should be highly polished and edges should be rounded off so that there are no sharp points.

A charged conical conductor loses charges earlier than similar charged sphere. Why?
The discharging action of sharp points in the conductor discharges the conductor. This is the reason of loss of electric charges from the sharp points. Hence the conical conductor loses its charges earlier than similarly charged sphere.

Explain the phenomenon of action of sharp points in conical sphere.
When the process of air molecules coming in contact with sharp points and moving away after getting similar charges is continued the conductor goes on losing its charge into atmosphere.

Electrostatic experiments do not work well on humid days. Explain
Dry air is considered to be insulator at ordinary condition. The presence of humidity makes the air conducting. So the non-conducting parts of apparatus becomes conducting due to which experiments fails to work. Hence, the electrostatic experiments do not work well on humid days.

Electric potential of earth is taken to be zero. Why?
Earth is a good conductor of very large size when some charge is given to it, its potential doesn’t change. Hence potential of earth is constant and taken to be zero. The potential of earth is considered as reference level and taken as zero potential.

Two lines of force never intersect each other?
At the point of intersection of two lines of force, two tangents can be drawn which gives two directions for electric field vector at that point which impossible.

Can two equipotential surfaces intersect each other?
An equipotential surface is normal to the electric field intensity. If two equipotential surfaces intersect, electric field at that point will have two directions which is not possible. Two equipotential surfaces cannot intersect at a point.

What do you mean by electron volt?
Electron volt is unit of energy used in atomic physics. When a charge q is accelerated through a potential difference of V volts, the energy gained by the charge = qV. When one electronic charge is accelerated through a potential difference of one volt, then the kinetic energy gained by the electron is called 1 electron volt.
1 electron volt = 1 eV = electronic charge x 1V=1.6x10-19x1V=1.6x10-19J

Give some basic differences between electric lines of force and magnetic lines of force.
Electric lines of force 	Magnetic lines of forces
1. Electric lines of force are always normal to the surface of charged conductor.
2. No electric lines of force exist inside the charged conductor
3. Electric lines of force are not close curves. 	1. Magnetic lines of force not necessarily are normal to the surface of magnet
2. Magnetic lines of force exist inside the magnetic substance
3. Magnetic lines of force are close curves
