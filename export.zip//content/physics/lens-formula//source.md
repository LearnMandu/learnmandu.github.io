---
title: Lens Formula
slug: lens-formula
parent_slug: physics
path: physics/lens-formula/
---

This note was submitted by Niranjan Gopali from Thankot, Kathmandu. 

Rotational Motion

Rotational Inertia: That property of an object to resist any change in its state of rotation. If at rest the body tends to remain at rest; if rotating, it tends to remain rotating and will continue to do so unless acted upon by a net external torque.

Torque: The product of force and lever-arm distance, which tends to produce rotation.

Center of Mass: The average position of mass or the single point associated with an object where all its mass can be considered to be concentrated.

Center of Gravity: The average position of weight or the single point associated with an object where the force of gravity can be considered to ace. Usually the same place as the center of mass.

Equilibrium: The state of an object when not acted upon by a net force or net torque. An object in equilibrium may be at rest or moving at uniform velocity; that is, not accelerating.

Centrifugal Force: An outward force that is due to rotation. In an inertial frame of reference, it is fictitious in the sense that it doesn't act on the rotating object but on whatever supplied the centripetal force; it is the reaction to the centripetal force. In a rotating frame of reference, it does act on the rotating body and is fictitious in the sense that it is not an interaction with an agent or entity such as mass or charge but is a force in itself that is solely a product of rotation; it has no reaction-force counterpart.

Angular Momentum: A measure of an object's rotation about a particular axis; more specifically, the product of its rotational inertia and rotational velocity. For an object that is small compared to the radial distance, it is the product of mass speed, and radial distance of rotation.
Angular Momentum = rotational inertia x rotational velocity (mvr)

Conservation of Angular Momentum: When no external torque acts on an object or a system of objects, no changes of angular momentum takes place. Hence, the angular momentum before an event involving only internal torques is equal to the angular momentum after the event

Gravity

Kepler's Laws of Planetary Motion:
1] Each planet moves in an elliptical orbit with the sun at one focus
2] The line form the sun to any planet sweeps out equal areas of space in equal time intervals
3] The squares of the times of revolution (days, months or years) of the planets are proportional to the cubes of their average distances from the sun.

Weightlessness: condition wherein gravitational pull appears to be a lacking.

Spring Tide: A high or low tide that occurs when the sun, earth, and moon are all lined up so that the tides due to the sun and moon coincide, making the high tides higher than average and the low tides lower than average

Neap Tide: A tide that occurs when the moon is midway between new and full, in either direction. Tides due to the sun and moon partly cancel, making the high tides lower and the low tides higher than average.

Gravitational Field: The space surrounding a massive body in which another mass experiences a force of attraction

Black Hole: The configuration of a massive star that has undergone gravitational collapse, in which gravitation at the surface is so intense that even the star's own light cannot escape.

Big Bang: The primordial explosion that is thought to have resulted in the expanding universe

Stability: In order for an object to be stable, its center of gravity must lie directly above a point of support

The state of motion of the center of mass in a system can only be changed by forces outside the system

Escape Speed: That speed which is sufficient to propel an object away from a planet, or any object

Tides: Tides are caused by the variation of force on the earth exerted by the moon (and the sun)
The effect of the moon is about 4 times greater than that of the sun.



Vibrations and Waves

Summary of Terms:

Sine Curve: A wave form traced by simple harmonic motion that is uniformly moving in a perpendicular direction, like the wavelike path traced on a moving conveyor belt by a pendulum swinging at right angles about the moving belt.

Amplitude: For a wave or vibration, the maximum displacement on either side of the equilibrium (midpoint) position.

Wavelength:the distance between successive identical parts of a wave

Hertz (Hz): unit of frequency; one vibration per second is 1Hz

Period: The time required for a vibration or a wave to make a complete cycle

Wavespeed: The speed with which waves pass by a particular point frequency x wavelength



Sound

Summary of Terms

Infrasonic: A sound frequency too low to be heard by the normal human ear. i.e. below 20Hz

Ultrasonic: A sound frequency to high to be heard by the normal human ear. i.e. about 20kHz

Compression: Condensed region of the medium through which a longitudinal wave travels.

Rarefaction: Rarefied region, or region of lessened pressure, of the medium throughout which a longitudinal wave travels.

Reverberation: Re-echoed sound.

Refraction: The bending of a wave through either a non-uniform medium or from one medium to another, caused by differences in wave speed.

Forced Vibration: The setting up of vibrations in an object by a vibrating force.

Natural Frequency: A frequency at which an elastic object naturally tends to vibrate, so that minimum energy is required to produce a forced vibration or to continue vibration at that frequency.

Resonance: The result of forced vibrations in a body when an applied frequency matches the natural frequency of the body.

Beats: A series of alternate reinforcements and cancellations produced by the interference of two sets of superimposed waves of different frequencies, heard as a throbbing effect in sound waves.

Carrier Wave: The wave, usually of radio frequency, whose characteristics are modified in the process of modulation.

Modulation: The process of impressing one wave system upon another of higher frequency.

Amplitude Modulation: A type of modulation in which the amplitude of the carrier wave is varied above and below its normal value by an amount proportional to the amplitude of the impressed wave.

Frequency Modulation: A type of modulation in which the frequency of the carrier wave is varied above and below its normal frequency be an amount that is proportional to the amplitude of the impressed signal. In this case, the amplitude of the modulated carrier wave remains constant.

Transverse Wave: A wave in which the individual particles of a medium vibrate from side to side perpendicularly to the direction in which the wave travels. (Strings)

Longitudinal Wave: A wave in which the individual particles of a medium vibrate back and forth in the direction in which the wave travels. (Sound)

Interference Pattern: The pattern formed by superposition of different sets of waves that produces mutual reinforcement in some places and cancellation in others.

Standing Wave: A stationary wave pattern formed in a medium when two sets of identical waves pass through the medium in opposite directions.

Doppler Effect: Change in frequency of sound or lighter due to relative motion of source and receiver.

Bow Wave: The V-shaped wave made by an object moving across a liquid surface at a speed greater than the wave velocity.

Shock Wave: The cone-shaped wave made by an object moving at supersonic speed through a fluid.

Sonic Boom: The loud sound resulting from the incidence of a shock wave.



Satellite Motion

Summary of Terms:

Satellite: A projectile or small celestial body that orbits a larger celestial body.

Ellipse: The closed oval-like curve wherein the sum of the distances from any point on the curve to both foci is a constant. When the foci are together at one point, the ellipse is a circle. The farther apart the foci, the more eccentric the ellipse.

Escape Speed: The speed that a projectile, space probe, or similar object must reach to escape the gravitational influence of the earth or celestial body to which it is attracted.

Equations, Equivalences, and Concepts:

The sum or KE and PE for a satellite are a constant at all points along its orbit.

For a satellite in circular orbit, it is always moving perpendicularly to the earth’s gravitational field.

Because a satellite moves at right angles to the earth’s gravitational field, no change in speed occurs - only a change in direction.

The higher the orbit of a satellite, the less it’s speed and the longer its period.



Electrostatics

What determines resistance?

Type of material, shape and size; like a hose-bigger means less R, longer means more R

Electric current flows from high potential to low potential (volts)

Thus in a -12v DC battery the current travels from - to +

How are electricity and gravity the same?

They both a forces, and follow the inverse-square law

How are they different?

Electricity is a much stronger force

Gravity is exclusively attractive, while electricity is both repellant and attractive

Electrostatics: The study of electric charges at rest relative to one another

Capacitor: An electrical device, in its simplest form a pair of parallel conducting plates separated by a small distance, that stores electric charge.

Coulomb’s Law: the relationship among electrical force, charge, and distance.

Coulomb: the SI unit of electrical charge.

Conductor: any material thru which charge easily flows when subject to an external force.

Insulator: any material that resists charge flow thru it when subject to an external force.

Semiconductor: a poorly conducting material, such as crystalline silicon or germanium that can be made a better-conducting material by the addition of certain impurities or energy.

Charging by contact: The transfer of charge from one substance to another by physical contact between substances.

Charging by induction: the change in charge of a grounded object, caused by the electrical influence of electric charge close by but not in contact.

Electrically polarized: term applied to an atom or molecule in which the charges are aligned so that one side is slightly more positive or negative than the opposite side.

Electric field: the energetic region of space surrounding a charged object. About a charged point, the field decreases with distance according to the inverse- square law.

Electric potential energy: the energy a charge possesses by virtue of its location in an electric field.

Electric potential: the electric potential energy per amount of charge, measured in volts, and often called voltage.

Potential difference: the difference in voltage between two points, measured in volts.

Electrical Resistance: the property of a material that resists the flow of an electric current thru it. (Ohms).

Superconductor: a material in which the electrical resistance to the flow of electric current drops to near zero or zero under special circumstances that usually include low temperatures.

Direct Current: an electric current flowing in one direction only.

Alternating Current: electric current that repeatedly reverses its direction; the electric charges vibrate about relatively fixed points. In the U.S. the vibrational rate is 60Hz.

Electric Power: the rate of energy transfer, or the rate of doing work; the amount of energy per unit time, which electrically can be measured by the product of current and voltage. Measured in watts or kilowatts.

Series circuit: an electric circuit with devices having resistances arranged in such a way that the same electric current flows through all of them.

Parallel circuit: an electric circuit with two or more resistances arranged in branches in such a way that any single one completes the circuit independently of all the others.

Notes:

Electrons can be forced into vibration by the vibration electric fields of electromagnetic waves


Color

At the resonant frequencies where the amplitudes of oscillation are large, light is absorbed. But at frequencies below and above the resonant frequencies, light is re- emitted (reflected)
An object can only reflect frequencies that are present in the illuminating light.

A red piece of glass appears red because it absorbs all the colors that compose white light, except red, which it transmits.

The energy of the absorbed frequencies increase the kinetic energy of the molecules and the glass is warmed.

Any of the three additive primaries can be produced by a combination of any two of cyan, magenta, or yellow pigments. The latter three are called subtractive primary colors.

A color plus its opposite (complementary) produce white.

The tinier the particle, the higher the frequency of light it will scatter.

Of the visible frequencies violet light is scattered the most, followed by blue, green, yellow, orange, and red.

When white light passes through a thick atmosphere, the higher frequencies are scattered the most while the lower frequencies are transmitted with minimal scattering.

As the day progresses and the sun is lower in the sky, the path through the atmosphere is longer, and more blue is scattered from the sunlight. The removal of blue (through scattering) leaves the transmitted light more reddish in appearance.

Water is transparent to nearly all the visible frequencies of light, but strongly absorbs infrared waves.

Water molecules very weakly resonate in the visible red, which causes a slight absorption of red light in water. Red light is reduced to a quarter of its initial brightness by 15 meters of water.

Terms:

Additive primary colors: The three colors, red, blue, and green, that when added in certain proportions will produce any color in the spectrum.

Subtractive primary colors: The three colors of absorbing pigments-magenta, yellow and cyan- that when mixed in certain proportions will reflect any color in the spectrum.

Complementary colors: Any two colors that when added produce white light.


Reflection and Refraction

Fermat’s Principle: Out of all possible paths that light might take, to get from one point to another, it takes the path that requires the shortest time.

Law of Reflection: The angle of incidence equals the angle of reflection.

Plane mirrors: The observer sees the image of a candle at a point behind the mirror. The light rays do not actually come from this point, so the image is called a virtual image.

Causes of refraction: the bending is caused by a change in speed.

Dispersion: Violet light travels about one percent slower in ordinary glass than does red light.

Terms:

Reflection: the return of light rays from a surface in such a way that the angle at which a given ray is returned is equal to the angle at which it strikes the surface. When the reflecting surface is irregular, light is returned in irregular directions; this is diffuse reflection.

Refraction: the bending of an oblique ray of light when it passes from one transparent medium to another.

Critical angle: the minimum angle of incidence at which a light ray is totally reflected within a medium.

Total internal reflection: the total reflection of light traveling in a medium when it strides on the surface of a less dense medium at an angle greater than the critical angle.

Converging lens: A lens that is thicker in the middle than at the edges and refracts parallel rays passing through it to a focus.

Diverging lens: A lens that is thinner in the middle than at the edges, causing parallel ray passing through it to diverge.

Virtual image: an image formed by light rays that do not converge at the location of the image. A virtual image is that reflected by a mirror; it cannot be displayed on a screen.

Real image: An image formed by light rays that converge at the location of the image. A real image can be displayed on a screen.

Aberration: a limitation on perfect image formation inherent, to some degree, in all particle systems.


Light Waves

A soap bubble appears iridescent in white light when the thickness of the soap film is about the same as a wavelength of light.

Bright fringes occur when waves (from both slits) arrive in phase; dark areas result from the overlapping of waves that are out of phase.

Diffraction grating disperses white light into colors, and is used in spectrometers.

The amount of diffraction depends on the wavelength of the wave compared to the size of the obstruction that casts the shadow. The longer the wave compared to the obstruction, the more the diffraction occurs.

Terms:

Huygens’ Principle: the theory by which light waves spreading out from a point source can be regarded as the superposition of tiny secondary wavelets.

Diffraction: the bending of light around an obstacle or through a narrow slit in such a way that fringes of light and dark or colored bands are produced.

Interference: the superposition of waves producing regions of reinforcement and regions of cancellation. Constructive interference refers to regions of reinforcement; destructive interference refers to regions of cancellation. The interference of selected wavelengths of light produces colors known as interference colors.

Polarization: the alignment of the electric vectors that make up electromagnetic radiation. Such waves of aligned vibrations are said to be polarized.

Hologram: a two dimensional microscopic diffraction pattern that shows three dimensional optical images.



Light Emission

Summary of terms:

Excitation: the process of boosting electrons in an atom or molecule from a lower to a higher energy level.

Emission Spectrum: the distribution of wavelengths in the light from a luminous source.

Spectroscope: an optical instrument separates light into its constituent frequencies in the form of spectral lines

Incandescence: the state of glowing while at a high temperature, caused by electrons in vibration atoms and molecules that are shaken in and out of their stable energy levels, emitting radiant energy in the process. The peak frequency of radiant energy is proportional to the absolute temperature of a heated substance; f ~ t

Absorption Spectrum: a continuous spectrum, like that of white light, interrupted by dark lines or bands that result from the absorption of certain frequencies of light by a substance through which the radiant energy passes.

Fluorescence: the property of absorbing radiant energy of one frequency and re-emitting radiant energy of lower frequency. Part of the absorbed radiant energy goes into heat and the other part into excitation; hence the emitted radiant energy has a lower energy and therefore a lower frequency than the absorbed radiant energy.

Phosphorescence: a type of light emission that is the same as fluorescence except for a delay between excitation and de-excitation, which provides an afterglow. The delay is caused by atoms being excited to energy levels that do not decay rapidly. The afterglow may last from fractions of a second to hours, or even days, depending on the type of material, temperature, and other factors.

Laser (light amp. by stimulated emission of radiation): an optical instrument that produces a beam of coherent monochromatic light.

Notes=C/F

The temperature of incandescent bodies, whether they be stars or blast-furnace interiors, can be determined by measuring the peak frequency of radiant energy they emit.

Incoherent white light contains waves of many frequency (and wavelengths) that are out of phase with one another

Light of a single frequency and wavelength is still out of phase

Coherent light: all the waves are identical and in phase.



Light Quanta

When the energy of a photon is divided by its frequency, the single number that results is the proportionality constant, called Planck’s constant, h (6.6 x 10-34 joule- sec)

Observations contrary to the wave picture for the analysis of photo electricity:

1] the time lag between turning on the light and the ejection of the first electrons was not affected by the brightness or frequency of the light. 2] The effect was easy to observe with violet or ultraviolet light, but not with red light. 3] The rate at which electrons were ejected was proportional to the brightness of the light. 4] The maximum energy of the ejected electrons was not affected by the brightness of the light, but there were indications that the energy did depend on the frequency of the light.

-One photon is completely absorbed by each electron ejected from the metal. (All or nothing)

-the energy of each photon is proportional to the frequency of light, while the number of photons has to do with its brightness.

-light travels as a wave and hits as a stream of photons

The act of observing something as tiny as an electron produces a considerable uncertainty in either its position or its motion.

Summary of terms:

Complementarity: (Bohr) the principle that wave and particle models of either matter or radiation complement each other and when combined provide a fuller description of either one.



The Atom and the Quantum

Notes: The electron doesn’t radiate light while it accelerates around the nucleus in a single orbit, but that radiation of light takes place only when the electron jumps orbit from a higher energy level to a lower energy level.

Color depends on the (distance of) jump. Bohr’s views explained the regularities being found in atomic spectra.

Summary of terms:

Ritz combination principle: the theory that the spectral lines of the elements have frequencies that are either the sums or the differences of the frequencies of two other lines.

de Broglie matter waves: the associated wave properties of all particles of matter. The wavelength of a particle wave is related to its momentum and Planck’s constant, l=h/momentum

Shrodinger’s wave equation: the fundamental equation of quantum mechanics, which interprets the wave nature of material particles in terms of probability wave amplitudes.

Correspondence principle: the rule that a new theory is valid provided that, when it overlaps with the Old, it agrees with the verified results of the old theory.
