---
title:  Diffraction of Light Waves 
slug: diffraction-of-light-waves
parent_slug: physics
path: physics/diffraction-of-light-waves/
---

 Though this question is not being asked for long questions, it is an important topic for short questions. Differences of diffraction with interference is among frequently asked long question in HSEB Physics Grade 12 exam.

Definition: The phenomenon of bending of light round the corners and spreading into the regions of the geometrical shadow is called diffraction. (It occurs with all waves including sound waves, water waves, and electromagnetic waves such as visible light, x-rays and radio waves.)

![Alt](http://4.bp.blogspot.com/-oahRwItj69o/T__fPLV_X1I/AAAAAAAAASA/RJibGDH2F4U/s1600/diffraction-through-an-opaque-body.jpg "")

 In the above figure (a), when a narrow slit AB is placed in the path of the light, then only part A′B′ of the screen should be illuminated and no light should enter the regions XA′ and B′Y of the screen. Similarly, when an obstacle AB is placed as shown in the figure (b), then its distinct geometrical shadow A′B′ is obtained.

This only happens when the size/length of the slit or the obstacle is large. But when the size of obstacle is (made) small, light enters in the region of geometrical shadow. Such phenomenon (entering of light in the geometrical region) is known as diffraction of light.

Required Conditions
The light waves are diffracted only when the size of the obstacle is comparable to the wavelength of the light. The size of obstacle/slit shouldn’t be large in size.

Examples:

    Colours seen in a spider web when it is facing the sunlight.
    The rainbow like colour pattern seen in CDs, DVDs.

Diffraction Grating
Grating here means a regularly spaced collection of identical and parallel light waves. Diffraction grating is an optical component with a periodic structure which splits and diffracts light into several beams travelling in different directions. The directions of these beams depend on the spacing of the grating and the wavelength of the light so that the grating acts as the dispersive element.

Diffraction Pattern in Image
We can take an example of image diffraction in camera lens. When the light forming an image passes through a lens aperture, the wave front is distorted in much the same way as an ocean wave is distorted which causes the reduction in image resolution or makes the image blur. This sort of distortion effect is called image diffraction.

Resolving Power of Optical Instrument
It is the ability (of the optical instrument) to produce separate and distinguishable images of two objects lying very close to each other.]

Consider two points on the object that are close together. It is possible that their images may possess diffraction patterns that will overlap and if they are too close, the images of these two points will be indistinguishable from one another.

Resolving power of a Telescope:
When we are observing two stars that are very close together and their images should be separated, the aperture of the telescope needs to be as large as possible to give as little diffraction as possible.
Mathematically,

![Alt](http://4.bp.blogspot.com/-YXZDcumdZWE/T__fSpUU67I/AAAAAAAAASI/JUVAFYbRckQ/s1600/equation-for-the-resolving-power-of-a-telescope.gif "")

 Where D = diameter of the objective lens, and λ is the wavelength of the light used.

 Difference between Diffraction and Interference
Diffraction 	Interference

    It is the phenomenon of interaction of light coming form different parts of the same wave front.

	

    It is the phenomenon of interaction of light coming from two different wave fronts originating from two coherent sources.

    Diffraction fringes are not of the same width.

	

    Interference fringes may or may not be of the same width.

    Points of minimum intensity are not perfectly dark.

	

    Points of minimum intensity are perfectly dark.

    All bright bands are not of the same intensity.

	

    All bright bands are of uniform intensity.

