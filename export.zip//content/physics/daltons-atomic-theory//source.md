---
title:  Dalton's Atomic Theory and Stoichiometry 
slug: daltons-atomic-theory
parent_slug: physics
path: physics/daltons-atomic-theory/
---

 Stoichiometry is the branch of chemistry which deals with the weight relationship in chemical reaction and weight relationship that prevails in a chemical compound.
Dalton’s atomic Theory
In 1808, John Dalton gave his atomic theory and successfully explained the laws of chemical combinations. Before that philosophers were puzzled about the nature of matter. This theory is the milestone in the development of modern chemistry. The original statement given by Dalton has undergone expansion, modifications and clarification to a great extent. The main postulates of this theory are as follows.

    All matter consists of extremely small indivisible particles called atoms.
    Atoms of same elements are all alike.
    Atoms of different elements are entirely different, and have different properties.
    Atoms cannot be destroyed, created or transformed into atoms of other elements.
    Atoms combine together in simple whole number ratio to give compounds.
    The relative number and kinds of atoms are constant in a given compound.

The quantitative relationship of chemical combination is governed by the following laws of stoichiometry. Statements of these theories are given below.

The Law of Conservation of Mass: This law was stated individually by two chemists M.V. Lomonosov (in 1756) and Antoine Lavoisier (in 1774). It states that, “Mass is neither gained nor lost during a chemical reaction OR The total mass of the reactants (consumed) during a chemical reaction is equal to the total mass of products formed”

The Law of Constant (definite) Proportion: This law was given by a French chemist Joseph Louis Proust in 1799. It states that, “The same chemical always contain same elements combined together in definite proportion by weight regardless of the origin of the compound."

Law of Multiple Proportion: It was given by John Dalton in 1803. It states that, “When one element combines with another element to form two or more different compounds, then the weights of one of the elements which combine with the constant weight of the other bear a simple whole number ratio to one another.”

Law of Reciprocal (equivalent) Proportion: It was given by Richter in 1792. It states that, “When two different elements combine separately with the same weight of the third element, the ratio in which they do so will be the same or simple multiple ratio in which they unite with each other.”

Gay Lussac’s Law of Gaseous Volumes: It states that, “Whenever gases react, they do so in volumes which bear a simple ratio to one another and to the volumes of the products if these are also gases provided all measurements are made under similar conditions of temperature and pressure."
