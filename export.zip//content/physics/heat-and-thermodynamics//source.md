---
title:  Heat and Thermodynamics 
slug: heat-and-thermodynamics
parent_slug: physics
path: physics/heat-and-thermodynamics/
---

 What is heat?
Heat is a form of energy which gives us sensation of warmth. In other words, we can define heat as the total sum of kinetic energy produced due to the vibration of molecules of the element. Its unit is Joule (J) in SI system and calorie in CGS system.

What is temperature?
The degree of hotness or coldness of body is called temperature. It is also defined as the property by virtue of which identify whether the body in thermal equilibrium or not. When two bodies are in thermal contact they posses a common property which is represented by a numerical value is called temperature. Temperature is measured by thermometer. Its unit is Kelvin.


What is temperature of vacuum?
Since vacuum doesn’t contain molecules or atoms, its temperature is zero because heat energy is the sum of KE of all the molecules present in any substance and temperature is the average KE of all the molecules.

But, according to the radiation theorem, there is no radiation free space in the universe to vacuum also contains temperature or heat which depends as upon the energy density of radiation. Hence, the temperature of vacuum is still a topic to be discussed.

What is thermometre? Write the name of different thermometre?
The instrument which deals with the measurement of temperature is called thermometre. The different types of thermometres are:

    Liquid thermometer: These types of thermometres are based on the principle of change in volume with in temperature. Example: Mercury Thermometer, Alcohol Thermometer etc.
    Gas thermometer: These types of thermometres are based on the principle of change in volume and pressure with change in temperature. Example: constant volume hydrogen gas thermometer etc.
    Resistance thermometer: It is based on the principal of change in resistance with change in temperature. Example: Platinum resistance thermometer. It measures temperature between -240°C to 700°C.
    Thermo-electric thermometer: This type of thermometer is based on the principal of production of EMF in thermo-couple in which two junctions are at different temperature. It measures the temperature between 240°C -2300°C.
    Radiation thermometer: This type of thermometer is based on the principle of radiation emmited by a body. It is also measured high temperature. They are also called pyrometers.
    Vapour pressure thermometer: It is based on the principal of change in vapour with change in temperature. Example: helium vapour pressure thermometer.


Gas thermometer is superior to mercury thermometer. Why?
Gas thermometer is superior than mercury thermometer because,

    Expansion of gases is much higher than mercury thermometer.
    Gas thermometer has wide range of temperature scale.
    Gases are most found in pure state.

What are temperature scales?
The different temperature scales are described below:

    Celsius scale or Centigrade scale: In this temperature scale the lower fixed (freezing point) is taken 0°C and upper fixed point (boiling point) is taken 100°C. The distance between lower fixed point and upper fixed point is divided to 100 equal parts in which each part represents 1°C.
    Fahrenheit Scale: In this temperature scale the lower fixed point is taken as 32°F and upper fixed point as 212°F. The space between lower and upper fixed point is divided into 180 equal parts. Each part is called 1°F.
    Reaumer scale: In this scale, the lower point is taken as 0°R and upper fixed point is taken as 80°R. The space between lower and upper fixed point is divided into 80 equal parts. Each part is called 1°R.
    Kelvin scale: In this scale, the lower fixed point is taken as 273K and upper fixed point is taken as 373K. The space between lower and upper fixed point is divided into 100 parts. Each part is called 1K.

*Note: Kelvin scale is considered as the absolute scale among all the scales because it is standard and based on the molecular vibration.

What is triple point of water? Why it is taken as the standard fixed point in modern Thermometry?
Triple point of water is defined as the point at which the solid, liquid and gas state of water co-exists at fixed pressure (0.46 atm) and temperature of 273 K. This triple point of water doesn’t change with the change in pressure but MP and BP of water changes with pressure in presence of impurities. Because of this reason, triple point of water is taken as the standard fixed point in modern thermometry.

When a mercury thermometer is laid out in direct sunlight, what temperature does it measure?
When a mercury thermometer is laid out in direct sunlight, it neither measures the temperature of sun nor the temperature of the air because the bulb of thermometer isn’t in thermal contact with air and sun instead it measures its own temperature of mercury in it.

What is calculation of thermometer? Define MP and BP of a liquid.
The process of determining the upper fixed point and lower fixed point in the thermometer is called calculation of thermometer.

The temperature at which pure ice melts under standard pressure is called MP and the temperature at which the pure water boils is called BP. Melting point and Boiling point are also called lower fixed point and upper fixed point respectively.

What is absolute zero temperature? Why it is not a zero energy temperature?
It is the smallest possible temperature in the universe. At this temperature, molecular vibration of all objects is seized or stopped. Its value is 0K in Kelvin scale and -273°C in Celsius.

Absolute zero temperature is not a zero energy temperature because total energy of molecule or atoms present in any substance is the sum of KE and PE. In which at absolute zero temperature is zero but PE isn’t equal to zero.
     i.e. ET = KE + PE
    Or, ET = PE (Because KE=0 at T=0K)
          Hence, ET≠0

Why does heat flows from body at higher temperature to body at lower temperature?
Because, body at higher temperature has higher average KE of molecules and body at lower temperature has lower average KE of molecules. When two bodies having higher temperature and lower temperature are keep in contact, the body at higher temperature shares their energy to molecules at lower temperature.
