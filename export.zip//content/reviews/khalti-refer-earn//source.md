---
title: Khalti Digital Wallet Review
slug: khalti-refer-earn
parent_slug: reviews
path: reviews/khalti-refer-earn/
---

## Introduction

Khalti is an online payment service or a digital wallet. It was launched over a year ago and gaining in popularity.

## Availability

Available in both Google play store and Apple store.


## Features

* Fund can be loaded from multiple banks(Machhapuchchhre, Mega, NMB, NIBL, NIC Asia). 
* Fund can be transfered from one account to the other, using the mobile number.
* QR code scanner to do transfer and payments
* Payment features for Mobile balance, landline bill, Dish home, SimTv, ADSL, Recharge card, Subisu,Worldlink, NEA, Midas, Kaspersky, Khanepani, Vianet. etc
* Movie booking, Flight booking and Hotel booking. 

## Shortcomings

* It still hasn't been integrated with major online businesses such as [kaymu.com](kaymu.com), QFX Cinemas etc.
* Does not have withdrawl feature yet.
* Does not have many major banks.

I hope they overcome these major shortcomings in the following days, which I hope they will add as early as possible
given that they have been growing fast these couple of days.

## Summary

The application is very user friendly and easy to use. Lately, it's been getting lots of
attention due to it's cash for referal and joining policy. But considering the features it
already provides and looking to provide, people might(I am already) get hooked to it. 
Therefore i think it's here to stay. 

## Recommendation

Highly recommended
