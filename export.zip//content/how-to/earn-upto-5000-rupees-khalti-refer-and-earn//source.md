---
title: How To Earn upto Rs. 5000 By Joining Khalti
slug: earn-upto-5000-rupees-khalti-refer-and-earn
parent_slug: how-to
path: how-to/earn-upto-5000-rupees-khalti-refer-and-earn/
---

Yes! You read it right. You can actually earn upto Rs. 5000 by joining [Khalti](https://khalti.com/info/refer-earn) and referring your friends to join Khalti.

## Introduction
Khalti is a digital wallet and a online payment gateway for Nepali citizens.
We have a short review for Khalti that you can [read here](https://learnmandu.com/learn/reviews/khalti-refer-earn/).

## Earn during sign up

If you already have a khalti account then skip to the next section. This section is for users who have not signed up for Khalti as of yet.
Here are the steps you need to take to earn referral bonus right away.

* Find someone who is using khalti and ask for their referral link. Don't worry, they'll be very happy to provide you their referral link.
* Go to that link and download the khalti app and signup.
* You'll see that your account has Rs. 10 once the sign up is complete.
* Click on the *Fill kyc form* button and submit your information. You'll receive Rs. 20 once your KYC is verified.
   It might take up to few days for KYC to be verified.
* If you have an online bank (ebanking) account in one of the banks Khalti supports then you can also earn additional Rs. 15 when you load fund for the first time.
* If you don't have an ebanking account then you can load funds using epay's kiosks. [See here](https://www.google.com/maps/d/viewer?hl=en&mid=1DXeUBiNB4IomUJzr5rotTIhk40Y&ll=27.705851371370407%2C85.31586117230233&z=13) for locations of ePay kiosks.
* Now it's time for you to earn more, go to the next section.

## Earn by referring
If you already have a Khalti account, you might have already received a bonus if you'd used someone's referral link. If you did not sign up using a referral code then you received no bonus but don't worry, you can still earn up to Rs. 5000. Follow these steps. 

* Login to Khalti
* Go to side menu bar and tap on Refer and earn or directly tap on the banner of ‘Refer and Earn’ from home screen. 
* Now enter the phone number of the person whom you want to refer and click on ‘Send’ or simply share your referral link using Whatsapp, Messenger or any other messaging platform. 
* Your Khalti Wallet will be credited with Rs 10 when the friend you referred signs up to Khalti, Rs 15 if the person loads funds for the first time and with Rs 20 when the person gets his/her KYC verified within one week of signup using the referral code

**Make sure before you try this you have updated the Khalti App to the latest version**

For more info on refer and earn, visit the [official khalti website](https://khalti.com/info/refer-earn).
