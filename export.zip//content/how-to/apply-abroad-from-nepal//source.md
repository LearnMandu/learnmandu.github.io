---
title: How to apply for studying abroad
slug: apply-abroad-from-nepal
parent_slug: how-to
path: how-to/apply-abroad-from-nepal/
---

WIP
