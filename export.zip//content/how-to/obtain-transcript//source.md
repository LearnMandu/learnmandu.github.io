---
title: How to obtain transcript
slug: obtain-transcript
parent_slug: how-to
path: how-to/obtain-transcript/
---

WIP
