---
title: How to enable FNF (Friends and Family) and My5 call services
slug: ntc-ncell-fnf-nepali-telecom
parent_slug: how-to
path: how-to/ntc-ncell-fnf-nepali-telecom/
---

This article will teach you how to enable FNF and My5 service in NTC and Ncell respectively.

## NTC

**Applicable for:** This service is available for Post-paid, and Prepaid subscribers of SkyPhone and GSM cards.

By enabling this feature mobile users can make calls to 5 and only 5 other NTC phone numbers (mobile and landline) at a discounted price at any time of the day.


### How to enable

* To add a new number type < FNFSUB\*No1> send it to 1415. Replace *No1* with your desired number.
* To modify a number type < FNFMOD\*OLD No*New No> send it to 1415.
* To delete a number type < FNFDEL\*No> send it to 1415.
* To inquiry about FNF type < FNFINQ > send it to 1415.

Learn more on the official [NTC website](https://www.ntc.net.np/pages/view/friends-and-family-call-service-fnf).


## Ncell

**Applicable for:** This service is available Ncell prepaid users only.

Ncell call's it My5 service where you can add upto 5 close people to get calls at a discounted rate of 1.24 paisa per minute.
Ncell will deduct Rs. 25.09 per month from your balance if you enable this service.
You will also be charged Rs. 6.27 to add, remove, change or delete a number from your My5 group after you've added the first 5 numbers.

* To activate: Dial 5599 or \*5599# and then press 1
* To add numbers in your group: Dial 5599 or \*5599# and then press 2
* To modify numbers in your group: Dial 5599 or \*5599# and then press 3
* To delete numbers in your group: Dial 5599 or \*5599# and then press 4
* To know the list of numbers in your group: Dial 5599 or \*5599# and then press 5

Read more on [Ncell's website](https://www.ncell.axiata.com/Services/Utilities/My5) and see tariffs [here](https://www.ncell.axiata.com/Mobile/Pro/My5-for-Pro).
