---
title: How to get started in Nepali share market
slug: get-started-nepali-share-market
parent_slug: how-to
path: how-to/get-started-nepali-share-market/
---

## Introduction

If you are interested in becoming an investor in the Nepali share market but have no clue where to start then you've come to the right place. 

This guide is intended for beginners in Nepali share market. If you have anything to add, contribution is appreciated.

## Terminology

When it comes to investing, there are many terms that may seem alien to people from different background than finance.

### NEPSE
NEPSE stands for Nepal Stock Exchange. It is the main*regulatory body* that overseas all stock and bonds transactions. 

### publicly traded companies
Companies who have chosen to make their shares available for the public to purchase and sell through NEPSE are publicly traded companies of Nepal.

### IPO
IPO means initial public offering.
