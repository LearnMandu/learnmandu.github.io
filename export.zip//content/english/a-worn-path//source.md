---
title:  A Worn Path - Eudora Welty 
slug: a-worn-path
parent_slug: english
path: english/a-worn-path/
---

 The story “A worn Path” is remarkable for various aspects. One of them is the mild humour connected with the character, Phoenix Jackson. Besides being strong and adventurous she is found to have a subtle sense of humour. We find it in her behavior with a white man, while she was lying in the ditch the white man pulled her out of it. There she explained that she was lying back like a June-Bug waiting to be turned over. At the same time when he asked her about her age, she pointed out that she would never tell him about it.


In addition to it, one can find out some humourous events in the story. The instance of picking the nickel that feel out of the white man’s pocket is quite humourous. In order to do so she diverted his attention to the fight of the dogs. Before that she instigated that fight. When he was away to attend the fight, she bent down with a great difficulty and care to lift the coin from there. Once she slipped the nickel in her apron pocket she spoke out her thought loudly that god would be watching her steal the coin.


There are many other events which are quite humourous. For instance when she crossed the river by walking on the log in perfect balance she felt that she was not as old as she thought. There she imagined a little boy bringing her a little plate with a slice of marble cake on it. Although it was her imagination she took it as the reality and went to take it by saying that it would be acceptable. This kind of behavior adds a touch of humour.

At one occasion, she mistook a scarecrow for a ghost. Her behavior at the doctors’ office is equally humourours. It is so because she forgot the very reason why she was in the hospital. A nurse had to remind her in other words she was reminded of the reason when the nurse asked her about her grandson’s throat infection. Thus right from the beginning up to the end readers will find the story humourous and interesting. It is due to the narrative skill of the writer.
