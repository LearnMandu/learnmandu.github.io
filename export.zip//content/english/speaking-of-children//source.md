---
title:  Speaking of Children -Barbara Holland 
slug: speaking-of-children
parent_slug: english
path: english/speaking-of-children/
---

 The advantages of parents for having one child are quite obvious. One child is an appendage and it can be outnumbered by parents. It can be carried along on pleasure trips. The most important of all is the privacy, which remains intact. On the contrary, plural children will be the end of advantages and the beginning of disadvantages. They will be counter-culture in the house and the parents will be outnumbered. There will be no place left in the living room because of the toys all over. Long pleasure trips will be shortened.The parents will be obliged to adjust themselves according to new situation. First priority will have to be given to the children and their matters.The house will be at sixes and sevens. Above all, there will be no privacy for the wife and the husband.
They will be interfered and interrupted by the children at every possible moment. Surprisingly enough, due to lack of proximity, the husband and wife will be reduced to the stage of strangers unless some solution is found out to end the new problem.

Q. Does this essay speak in favour or against having many children? Give reasons.

The essay “Speaking of Children” is written by an American writer, Barbara Holland. It is an informal piece of writing made lively and effective through the device of conversation. It examines the negative aspects of having more than one child. Hence, it speaks against having many children.

The advantages of parents for having one child are quite obvious. One child is an appendage and it can be outnumbered by parents. It can be carried along on pleasure trips. The most important of all is the privacy, which remains intact. On the contrary, plural children will be the end of advantages and the beginning of disadvantages. They will be counter-culture in the house and the parents will be outnumbered. There will be no place left in the living room because of the toys all over. Long pleasure trips will be shortened. The parents will be obliged to adjust themselves according to new situation. First priority will have to be given to the children and their matters. The house will be at sixes and sevens. Above all, there will be no privacy for the wife and the husband. They will be interfered and interrupted by the children at every possible moment. Surprisingly enough, due to lack of proximity, the husband and wife will be reduced to the stage of strangers unless some solution is found out to end the new problem.

Since the writer has focused on the enlargement of the disadvantages for having plural children, it is clear that she is against having plural children.

