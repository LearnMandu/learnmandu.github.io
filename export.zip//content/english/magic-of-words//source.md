---
title: Magic of Words
slug: magic-of-words
parent_slug: english
path: english/magic-of-words/
---

* [Summaries](https://drive.google.com/file/d/0B7gXFbMQlOIPdmRxSTdZUDhxVmc/view)



### One Sentence Summaries

My heart leaps up when I behold
The poem “My hear Leaps up When I Behold” is about the joy the poet feels at the sight of a rainbow which has been source of his ecstasy since his childhood and will continue to be so till his old age.

Speaking of Children
One child is an appendage and the parents can have privacy and proper guidance of the child where as the plural children is the end of privacy and the beginning of the obligations.


Look at a Teacup
The writer who has decided to remain unmarried fearing disintegration, inherits chinacups from her mother which were bought in 1939 and they have the pictures of falling flowers, which are significant and symbolical.

A Worn Path 
“A worn path” is the story of an old Negro woman, Phoenix Jackson, who undertakes a long hazardous journey up to the town to fetch medicine for her grandson suffering from throat infection.


The Poplar Field
The poem “The Poplar Field” is the lamentation of the poet over the destruction of the poplar field that once provided shade, whispering sound, cool wind and melody of birds.

The Nightmare Life Without Fuel
The essay “The Nightmare Life Without Fuel” is a hypothetical situation in America during the late 1990s when dwindling fuel resources have pushed the developed nation towards the pre industrial state of 1800s.

Unchopping a Tree
However hard we try and succeed in unchopping a tree by using tackle and scaffholding, it will not be as strongly held as it used to be before chopping the tree and restoring things to their former state is literally impossible.

Keeping Things Whole
In spite of the face that the presence of one thing in the absence of other is an unavoidable situation, the poet is determined to move for keeping things whole.

Concrete Cat
The poem “Concrete Cat”, being an example of a concrete poem presents the word picture of a striped cat with raised tail, upside-down mouse by rear feet and whisker around the mouth showing its catness in action.

The Gardener 
"The Gardener" is the story dealing with the dual relationship between Helen Turell and Michael Turell as aunt and nephew on the one hand and on the other hand the unmarried mother and illegitimate son who gets killed in the battlefield.

On the Vanity of Earthly Greatness
Through the poem “On the Vanity of Earthly Greatness”, the poem announces his outlook by saying that all the things of earthly grandeur and power will be reduced in the end into things of non entity.

Malini
Being the story of love and hatred, the poetic play “Malini” presents the character Malini, the embodiment of love who wins the hears of people demanding for her banishment in contrast to other character Kemankar, the conservative man of hatred who rewards his well-wisher Supriya with death.


Oops! How’s that again
The essay “Oops! How’s That Again” gives a humourous account of tongue slips, spoonerisms and mistranslation with psychological explanations for such mistakes and the reason for our laughter to hear them.

The Six Million Dollar Man
The essay “The Six Million Dollar Man” is an interesting and scientific evaluation of each human being as infinitely precious and priceless although the dry weight of the human body costs 245.54 dollars a gram and six million dollars for the person having 24,436 grams of dry weight.
