---
title: The Poplar Field - William Cowper
slug: the-poplar-field
parent_slug: english
path: english/the-poplar-field/
---

William Cowper in his poem “The Poplar Field” shows us the link between human happiness with nature and appeals us to preserve it in order to keep ourselves happy.

The poplars which grew along the river Ouse have now been chopped down. The cooling shade the trees, the whistling sound made by the air while passing through the leaves and the image of poplars in the river Ouse are no longer there. Twelve years ago, when the poet first visited the place, he enjoyed the melodious songs of the black bird sitting under the cold shade of poplar. The poet is very sad now because he isn’t being able to hear the sweet songs of black buried anymore as the bird has flown away in search of shelter.

The trees which used to be on the river bank making the entire area beautiful that lent the poet their cool shade once, are now lying low on the ground. The poet feels that his days of life are passing away hurriedly. The poet thinks that he will die soon and his body will be buried under the soil but the poet is very sad that he would not be able to see growing up other trees in place of the chopped down poplars before his death. Seeing the destruction of poplars that represent entire nature, the poet realizes the link of nature with human happiness as he was very happy when the poplars were there and he is very sad now in their absence. Although human live is very short, the poet finds human happiness and enjoyments have much shorter life which die much before our death.


**“T is a sight to engage me if anything can”, what is the sight? How does the sight engage the poet?**

The sight is of the chopped down poplars which makes the poet think seriously.

On revisiting the place were beautiful poplars were there twelve years ago, the poet finds that poplars are lying on the ground as they have indiscriminately been chopped down. In the absence of the poplars, the place looks bare having no charm at all which makes the poet feel very sad. He thinks that he himself has to die very soon as his days are passing away hurriedly. However, the poet laments in nostalgic tone that it is impossible for him to see other rows of trees there in place of chopped down poplars making the area look beautiful again before his death. Although, human life is very short, the poet finds human happiness has much shorter life than human beings. As happiness is linked with nature, the poet appeals us to protect the nature for the sake of our own happiness.


**Consider the poem as a defense of nature conservation.**

 In the poem ‘the poplar field’, the poet powerfully presents the threatening to our environment from all around and suggests the need to conserve it for the sake of the earth and its inhabitants. The poet appreciates the pristine wilderness, rural beauty and expresses his severe grief on their destruction because of unwise human activities.

The poet, through this poem inspires us to be sincere and devote ourselves to protect it. If we keep our unwise act of chopping down trees indiscriminately, the entire environment will be affected badly by it jeopardizing the life on the planet. Besides calamities like landslide, soil erosion, flood, drought, green house effect and desertification, the lives of human beings as well as birds and animals will be jeopardized. Birds and animals will escape away to other places in search of shelters, river banks will be destroyed making the areas prone of flood and enhancing the risk of water pollution. Showing the link between human happiness with the nature and the consequences of unwise activities, the poet appeals us to conserve the nature for the sake of our own happiness.

