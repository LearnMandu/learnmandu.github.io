---
title:  The Last Voyage of the Ghost Ship - Gabriel Garcia Marquez 
slug: the-last-voyage-of-the-ghost-ship
parent_slug: english
path: english/the-last-voyage-of-the-ghost-ship/
---


Gabriel Garcia Marquez in his story The Last Voyage of the Ghost Ship which is written in Stream of consciousness style of writing describes the growth of an ordinary boy to an assertive (strong and confident) young man.


Many years ago, at night in the month of March the boy saw very large ship without light and sound while moving towards sandy beach near the village the boy saw the ship breaking and sinking into the sea but he didn’t hear any sound. The boy thought that he had a bad dream in the previous night as he didn’t see any wreckage at the place where the ship broke into pieces. The boy saw the same ship appearing at the same place and destroying like previous year and he was sure that he wasn’t dreaming. He told his mother about the ship but she didn’t believe him and thought her son became crazy. His mother used to spend almost her night sitting on her chair after the death of her husband 11 years ago. As the chair was very old she brought second hand chair from the market. But she died that very night sitting on the newly bought chair. Four more women from the same village also died sitting on the same chair. So the chair was thrown into the sea considering it is an evil chair. After the death of his mother the boy became orphan and started stealing fish form the boats to survive rather than depending on the charity of the villagers who had hated him.


A few years later at night in the month of March the boy saw the same ship while watching the ship. He shouted loudly calling the villagers to watch the ship. But when the villagers reached there, the ship had already broken and sunk into the sea. The poor boy was beaten badly for disturbing and scaring the villagers at midnight. The boy made a plan to show that them the ship so that they would believe him. A few years later in the same night of March, the boy stole a boat and kept waiting for the ship where he had seen in last year. When the ship arrived he lit a lamp on his boat, the ship followed the light and the boy let the ship towards his village. When the ship brought near the village, he blew its large whistle and lit all the lights. All the villagers wake up because of the sound and started coming out of their houses. The ship came onto the ground by the village and stopped moving in front of the church, then all the villagers saw the ship and believed the boy, the boy became very happy.
