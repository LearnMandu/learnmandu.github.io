---
title:  The Six Million Dollar Man - Harold J. Morowitz 
slug: six-million-dollar-man
parent_slug: english
path: english/six-million-dollar-man/
---

 Harold J Morowitz in his essay “The Six Million Dollar Man” examines the value of chemicals present in human body and arrives at a conclusion that human body is indeed invaluable.

Once the writer received a birthday greetings card where it was written that the material value of human body was worth only 97 cents. Being a scientist himself, the writer becomes curious and decided to examine the statement with the help of catalogues given to him by biochemical companies. He calculated various human body chemicals ranging from three dollars to 17 crore 50 lakh dollar per gram and discovered that the average value of human body chemical was $245.54 per gram. Further calculation brought the value of human body chemicals over six million dollar. On discovering this fact that he was a six million dollar man, the writer felt a great up graduation in his ego. Being a scientist, the writer calculated the human body chemicals in the highest informational and purified form whereas in the 97 cents figure printed on the birthday card, the calculation was done in the poorest informational state and for unpurified block of chemicals only.


We may procure the human body chemicals required to form a human body from bio-chemist lab. It is impossible to assemble the body chemicals into a complete human form. The collection of body chemicals can not be equalized with human being as it can not act and feel like human beings. After detailed analysis, finally the writer comes to the conclusion that human body is readily invaluable and it is improper to compare human beings in terms of money.
