---
title: Heritage of Words
slug: heritage-of-words
parent_slug: english
path: english/heritage-of-words/
---

The eBook contains summaries and important questions with answer from,

* Grandmother, Ray Young Bear
* About Love, Anton Chekhov
* The Lamentation of the Old Pensioner, W.B. Yeats
* Two Long-Term Problems: Too Many People, Too Few Trees, Moti Nissani
* Full Fathom Five Thy Father Lies, W. Shakespere 
* Hurried trip to avoid a Bad Star, M. Lilla and C. Bishop Berry
* Travelling Through the Dark, William Stafford
* A story, Dylan Thomas
* The Last Voyage of the Ghost Ship, Gabriel Garcia Marquez
* God’s Grandeur, Gerard Manley Hopkins
* I Have a Dream, Martin Luther King, Jr.
* Women’s Business, Ilene Kantrov
* The Children Who Wait, Marsha Traugot
* A Child Is Born, Germaine Greer
* The Tell-Tale Heart, Edgar Allan Poe
* Purgatory, William Butler Yeats
* The Boarding House, James Joyce
* Hansel and Gretel, Grimm Brothers, Jack Zipes

Download [The Heritage of Words Summaries and Important Questions v2.0](https://docs.google.com/file/d/0B7gXFbMQlOIPWDJ2SEF1Wk5Ca1E/edit)
