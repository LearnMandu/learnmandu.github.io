---
title:  Travelling Through the Dark - William Stafford 
slug: travelling-through-the-dark
parent_slug: english
path: english/travelling-through-the-dark/
---

 American poet William Stafford in his poem Travelling through the Dark presents the conflicts between physical action and emotion and responsibility to take appropriate course of action even in critical situation. The poet also satires the self proclaimed nature lovers who are responsible for the difficult state of wild animals and environmental degradation.


While driving on the edge of Wilson river road, once the poet saw a dead deer lying on the road. He stopped there to clear the road by pushing the deer off the road into the river as the road wasn’t wide enough. It was difficult to drive past the deer because the car might collide with the possible danger of falling off the road and get killed, the poet observe that the deer has been killed recently which was already stiff and almost cold. While pulling it to the corner of the road for pushing into the river, the poet observes its large belly and realized that the deer was pregnant. Although the body inside was still alive and waiting to be born, it was unlikely to born because its mother had already been dead. The poet was greatly confused in deciding correct of action in that difficult situation.


The lights of the car were on and the engine was making a low continuous sound. The animal with live inside it was lying dead on the road whereas, the lightless car seemed to be alive. Standing by the light of the car, the poet tell as if the tragic seen was being watched silently by wild animals too. He found himself in confusing state to choose appropriate step at this situation. However, accepting the ground reality and thinking seriously for other natural lovers, the poet changed his idea suddenly and pushed the deer into the river making the road free for others. Choosing the easy curse of action, the poet placed himself in the row of self responsible for ecological imbalance.


Using irony, the poet expressed that people are totally indifferent (careless) about the plight (sorrow) of wild animals because of their unwise activities. Although they are selfish and cruel towards the animals, they pretended to be nature lovers. The poet criticize this human behavior and satires their pretention as nature lovers who are in reality the source of problems and plight of the natural world.
