---
title:  Keeping Things Whole - Mark Strand 
slug: keeping-things-whole
parent_slug: english
path: english/keeping-things-whole/
---

 Mark Strand in his poem “Keeping things Whole” expresses that human beings always disturb the nature whereas nature always makes a balance to keep itself intact. The poet appeals for wholeness of nature against its usual fragmentation while performing daily activities in our life.

The poet says that while in the field, he considers himself as absence of the field; this is because the field is missing where he is standing. Wherever he is in the field, he displaces and occupies the part of the field that is missing (not visible). According to the poet, he divides the air when he walks. In other words, he disturbs the nature.
When he moves forward, the air comes from different directions to cover up the vacant space. In order to fulfill the desire, human beings always damage and disturb the nature. However, the nature always makes a balance by repairing itself. The poet tells us that while performing various activities in life, we should be very careful and should not disturb the nature rather we should support the wholeness of it. The poet says that people may have different reasons of moving, but the poet keeps moving to enable the nature to repair it by itself as he wants to keep the nature whole.
