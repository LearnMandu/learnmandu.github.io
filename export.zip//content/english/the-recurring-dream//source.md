---
title:  The Recurring Dream 
slug: the-recurring-dream
parent_slug: english
path: english/the-recurring-dream/
---

 What do you think is the reason some people have recurring dreams?
In my opinion I think the reason for some people have recurring dream is tiredness, work load, psychological or mental problem or it may be the continuous thinking about the same things or characters or dream.

Why do you think Kim has this dream?
Kim works at an office where daily there is lots of workload which creates tiredness or mental pressure. So due to this, Kim might have had this dream.



It says in the story that Kim simply goes into the house in her dream, but it doesn’t say how she enters. How do you think she enters? (Remember the ending of the story)
In her dream, Kim’s spirit is activated and spirit doesn’t need any entrance to go anywhere. Thus in this way, Kim could have entered the room. According to the ending of the story, Kim is a ghost.

In your opinion, why does Kim wake up each time she tries to speak to the man in her dream?
Kim wakes up each time she tries to speak to the old man in her dream because her body and spirit is interconnected.

Why does Janet want to take Kim to her parents’ farm for a few days?
Janet wants to take Kim to her parents’ farm for few days in order to make her mentally refreshed or she may forget about the terrible dream.

When Kim sees a cottage like the one in her dream, Janet doesn’t want her to go see it. Why?
When Kim sees a cottage like the one in her dream, Janet doesn’t want her to go see it because Janet doesn’t believe in Kim’s story.

Why does Kim’s body shake when she sees the little old man at the door of the cottage?
Kim’s body shake when she sees the little old man at the door of the cottage because as in her dream, everything was same i.e. her dream came true. She couldn’t believe it. She was very much surprised as all the things of her dream came true.

Why does the little old man close the door when he sees Kim?
The little old man closes the door when he sees Kim because according to him Kim is a ghost so he is scared of her.

Why does Kim say something about the FOR SALE sign?
When Kim sees the old man, she realized that her dream was true. Everything happened as in her dream so she was a bit surprised and also curious about it. She had no other idea to speak. She anyhow needed to find out the truth about the particular dream. So she said something about FOR SALE sign.

Why do you think the cottage is for sale?
In my opinion, I think the house is haunted by the ghost so due to this the cottage might be for sale.

