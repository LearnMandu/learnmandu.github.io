---
title: Purgatory - William Butler Yeats
slug: purgatory
parent_slug: english
path: english/purgatory/
---

The old man was born in the ruined house. His mother was an aristocratic woman who fell in love with a his father and married him despite the opposition from her family.


The old man’s mother died while giving birth to him. She wasn't alive to see when her husband wasted all her money on alcohol, women and playing cards. It is clear that the old man’s father destroyed the spirit of the house by doing wrong things.


The old man wasn’t sent to school but was taught by a priest and by the wife of a servant. The old man, on being complained by his son that he had not sent him to school, he told him that he didn’t deserve to go to school because he was the son of an unmarried, low class woman. This shows us that the old man prides of his mother's heritage. 


When the old man was sixteen years old, his father burnt down the house when he was drunk. Therefore, he stabbed his father to death with a knife which he kept using for cutting food. He was not arrested for the crime because it was impossible to prove that his father’s body had been stabbed to death as it was burnt very badly. After the murder, he ran away from the house and became a peddler.



It was his mother’s wedding anniversary and he saw his father riding home with a wine bottle under his arm. The old man heard the hoof beats of horse and a young lady appearing in the window. However, the boy says nothing and he was indifferent about the old man’s saying because he was tending to snatch away the bag containing money from the old man. The son threatened to kill the old man as he had not been given the due share of his property. The old man then killed his son with the same knife which he had used for killing his father. He believed to have broken a cycle of violence by stopping his son from murdering him. He thought that by killing his son, he had prevented to add more sin at his mother’s share. He believed that now his mother’s soul would be free from purgatory. However, he heard the hoof beats (walking sound of horse) of horse again which was an indication that the two murders of his father and his son did not render any help to get his mother’s soul free from purgatory. He thought that his mother committed mistake on herself which was not pardonable. He, therefore, cried out to god asking him to release his mother’s soul from purgatory.

In the short drama Purgatory, the writer WB Yeats expresses the following things:

* The crime of the father will be repeated by his son to an endless cycle of violence.
* Living beings can render help to the departed soul which suffers in purgatory.
* The living beings have to suffer the consequences of the sin committed by the dead while alive.

**What is the theme of purgatory?**

Purgatory is a story of remorseful of a departed soul that committed mistakes on itself while being alive. In order to purify itself, it is undergoing suffering in purgatory. It is also concerned with the living beings who suffer the consequences of the sin committed by the dead people while alive and the help rendered by the living beings to get the soul released from purgatory.

**What is the motive (aim) in murdering his son by the old man?**
The old man believes that by murdering his son, he has stopped the boy to have a son of his own who would kill him after attaining 16 years of age, thereby breaking the endless cycle of violence. He also believes that by killing his son, he helps his mother’s soul to get released from purgatory.
