---
title:  The Boarding House - James Joyce 
slug: the-boarding-house
parent_slug: english
path: english/the-boarding-house/
---

James Joyce in the story The Boarding House recollects his own days of youth in Dublin by drawing the characters of Mr. Doran and Mrs. Mooney.
Mrs. Mooney was a butcher’s daughter who married to the foreman of his father’s meat shop. After the death of her father, her husband started drinking alcohol and spending monkey from the shop. He started quarrelling with Mrs. Mooney in the presence of customers and soon ruined the business by selling bad meat. Once her husband chased her with large knife in order to kill her and she had to protect herself by hiding in neighbours house. After that incident, Mrs. Mooney left her husband, sold the meat shop and started a boarding house.

Most of the people staying in her boarding house were the workers from the city. Mr. Doran, an employee of an office used to live in the same house. Mrs. Mooney had a 19 years old daughter called Polly Mooney who helped her mother in doing the household work and running the boarding house. Mr. Doran was having a love affair with Polly Mooney. Mrs. Mooney was aware about the love affair but she kept pretending to be unknown about the affair, there by allowing them to proceed ahead in their affair Mrs. Mooney actually wanted Mr. Doran to marry her daughter. Finally, Mrs. Mooney asked about the affair to her daughter and Polly Mooney revealed everything about their love affair to her mother. Mrs. Mooney was happy but the love affair as Mr. Doran would have to marry her. If he didn’t agree to marry her, he would probably lose his job as the love affair was known to everyone in the city. Analyzing all the aspects of the situation, Mrs. Mooney called Mr. Doran in order to convince him to marry her daughter. Although, he was reluctant to marry miss Polly Mooney because of her education and family background. He was under pressure to accept the proposal because of the prevailing situation as the affair was already known to everybody. When Mrs. Mooney was trying to persuade Mr. Doran, Ms. Polly Mooney was making a future plan of life with Mr. Doran being very happy.
