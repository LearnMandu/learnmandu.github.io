---
title:  The Lost Doll 
slug: the-lost-doll
parent_slug: english
path: english/the-lost-doll/
---

 Why do you suppose almost everyone in the village attended Carmen’s funeral?
Carmen was very loveable child. Though she wasn’t healthy, she was bright, kind, lovely and beautiful child. She was so attractive that everyone falls in love with her. She amazed people with her cute little acts and behaviours. That’s why everyone in the village loved her so they attended Carmen’s funeral.

Why do you suppose the people marched single file to the cemetery?
In my opinion, I think that the people marched in a single-file procession to the cemetery because may be it was their culture, tradition followed by their ancestors or may be the road or the path might have been narrow. So the vehicles couldn’t go through that path.  



What indications are there in the story that the Soto family was poor?
The Soto family was really poor. Roberto had to work very hard to feed his family as a result he had very hard hands. Similarly, Carmen their daughter who was very sick since her birth died in a early age as the Soto’s couldn’t afford her medical treatment.  

Why do you think, Rosa gave Carmen’s things to someone from another village? (Why didn’t she give them to a neighbour or the priest of her own village?)
In my opinion, I think due to the un-sudden death of Carmen. Her family was in a great shock. Rosa didn’t want any emotional attachment with Carmen. She wanted to forget Carmen completely so she gave Carmen’s things to someone from another village.  

Why did Roberto want to save Carmen’s things?
After the un-sudden death of Carmen, Roberto still had hoped to have another child. Even though the doctor told them that it was difficult to have a baby, he still had hope. So he wanted to save Carmen’s things.  

Why did Rosa say that there was no reason to save them?
Rosa became very practical after the death of Carmen. She believed in the medical science and experiments. As the doctors told them that there was no hope after Carmen’s death. So Rosa said that there was no reason to save Carmen’s things.  

Rosa said to her husband, “False hope is not good.” When does hope becomes false? How can we know when hope is false?
Hope becomes false when it is not fulfilled. We know it when we fail to achieve the desire thing for a long time. Rosa’s hope was shattered as she couldn’t get another child for four years and her only child died sick.  

What did Rosa want to say when she said to her husband, “You know that in these four years……?” Finish the sentence for her.
Rosa wanted to say when she said to her husband that, “You know that in these four years, you had your hands fall with a sick child.”  

Why do you think Roberto thought of Carmen’s doll when he looked out the window to the backyard?
When Roberto looked out the window to the backyard, he thought of Carmen and her cute little acts then suddenly he thought of the doll that Carmen had. Carmen used to play with the doll every time. She never left the doll alone.  

What made them finally forget about the lost doll?
After one year of Carmen’s death, the Soto family welcomed their happiness. Good news came i.e. Rosa Soto became pregnant. This made them very happy which was lost due to the loss of Carmen. Thus, due to happiness, they were finally able to forget about the lost doll.  

Do you think Evangelina was a good name for the new baby? Explain.
Yes, in my opinion. I think Evangelina was a good name for the new child because the word Evangelina meant good news and due to the birth of Evangelina, the Soto family was complete. It brought pursuit of happiness in the family which was lost before due to the death of Carmen.
