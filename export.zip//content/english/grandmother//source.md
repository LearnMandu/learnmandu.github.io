---
title:  Grandmother - Ray Young Bear 
slug: grandmother
parent_slug: english
path: english/grandmother/
---

 American Indian poet Ray Young Bear in his poem Grandmother describes his grandmother using similes, metamorphose and sense verbs. Depicting (pointing) a portrait (image) of grandmother of his tribe. The poet also reveals (show) the socio-economic status of Mesquaki tribe which he belongs.


The grandmother of the poet is the source of love and inspiration for him. As the poet was closely associated with his grandmother, her image is evergreen in fresh in his mind if the poet saw his grandmother from a far distance he would instantly recognize her because of her purple scarf around her neck and plastic shopping bag in her hand. If the grandmother touch his hand were of his grandmother only because they would feel warm and damp with smell of root. This indicates poet’s poor financial state which made the grandmother work in the field despite her old age. If the poet heard a voice coming from the rock, he would immediately know that the voice was of his grandmother as it would blow inside him like a light and warm on stirring a dying fire at night. The words would be inspiring for him as they would activate his inner feeling making the loving memory of his grandmother evergreen and very fresh.


The poet is successful in drawing the picture of his grandmother which is appealing to our senses. Deviating (going away) from usual grammatical rules and rules of the poetry, the poet has used small letters in the entire poem to draw the attention to the readers. The poet also reveals the socio-economic status of ‘Mesquaki’ tribe to which he belongs.

What sense verbs does the poet use to describe his grandmother?
Or
How does the poet look towards his grandmother?
The poet has very affectionate and most respectful feeling towards his grandmother. His description of his grandmother in the poem using various poetic devices reveals that she is the source of love and inspiration for the poet. He seems to be strongly guided by the inspiration of his grandmother it is his close association with grandmother  that inspires him to recognize, feel and understand her even from a far distance without looking her appearance his imagination of blowing words of grandmother from the rock entering inside him, enlightened  him removing the darkness of his life. This words also inspire him to move forward enthusiastic way. The poet has evergreen and fresh memory of the grandmother which is highly motivated factor of his life. The poet is devotedly guided and inspired by the loving memory of his grandmother.
