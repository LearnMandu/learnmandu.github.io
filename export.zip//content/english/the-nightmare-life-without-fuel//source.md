---
title:  The Nightmare Life Without Fuel - Isaac Asimov 
slug: the-nightmare-life-without-fuel
parent_slug: english
path: english/the-nightmare-life-without-fuel/
---

 Isaac Asimov in his essay ‘The Nightmare Life Without Fuel’ depicts the horrible state of the world after the fuel is finished from the world. Showing the case of prosperous America which turns into a dark state of pre-industrial age because of fuel crisis, the writer draws our attention towards the vital need of preservation of fuel to avoid future crisis.

The writer assumes twenty years advance in time when the fuel is finished from the world. Because of fuel crisis, no vehicles are plying on the road making it very difficult for people to transport goods and to move to their destination. Being dangerous, nuclear fusion and fission to generate electricity is not being materialized. Being too expensive, solar batteries and other sources of energy are not being used.
Although, there is difficulty everywhere because of fuel crisis, it has the following advantages:

    There will no smoke from vehicles and industries so the air will be pollution free.
    Less people will suffer from cough and cold because of pollution free air.
    Crime rate will fall down because of mutual protection in crowd.
    Due to lack of other entertainment facilities, people will start utilizing natural source of entertainment.
    People will learn to live natural life without facilities such as central heating, shower bath with hot water etc.

The following will be the disadvantages of fuel crisis:

    People will be deprived from facilities which will make their life complicated.
    People will have to walk and carry goods by themselves.
    People living in suburbs will face acute problem bringing and storing food.
    High percentage of people will have health problems, even sustain brain damage
    Entertainment and printing materials will be curtailed depriving people from getting even information and news.
    There will be high death rate of infants as their mothers will go dry.

Outside America and Europe, only 20% people are being able to feed themselves. People are dying because of starvation and a large number of people are suffering from brain damage. According to report, such unhealthy people are being killed secretly to save food. There is a high death rate of infants because their mothers have gone dry due to lack of nutritious food. Armies have been almost disappeared from the world except few countries like America and Russia.

Finally, the writer laments not being aware and taking steps to save fuel in the past. He expresses if we started saving it 50 years ago, the current fuel crisis could have been avoided. In order to avoid such crisis in future, the writer draws our attention towards this issue and appeals us to start preserving fuel without any delay.

Explain, “The Suburbs were born with auto, lived with auto and are dying with auto”.
Suburbs are the areas just outside the large cities. With rapid industrialization and development, the cities became crowded. Therefore people started living little away from the cities enjoying equal opportunities as cities. Because of easy availability of automobiles (vehicles), the suburbs were come into existence. People living in the suburbs are fully dependent on the cities for educational, medical facilities, for their employment and for their daily provisions. Due to easy vehicular movement, they are living happily availing facilities like cities. Now with the fuel crisis, there to and from movements to the city and vice-versa are restricted because of non availability of vehicles. The restriction deprives them from enjoying the facilities which they have been enjoying up to now. Therefore, the people living in suburbs are now facing extreme difficulties in their life as they are now dying with auto.
