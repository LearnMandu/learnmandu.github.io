---
title:  Oops! What’s That Again - Roger Rosenblatt 
slug: oops-whats-that-again
parent_slug: english
path: english/oops-whats-that-again/
---

 Roger Rosenblatt in his essay “Oops! What’s that Again” classifies the mistakes people make while speaking in humourous tone with remarkable examples. He also describes the reasons of these mistakes from linguistic and psychological point of view.

Broadly, the writer classifies verbal mistakes into four categories as under:

    Slip of tongue: This type of mistake is very common. In such mistake, the speaker tell one thing when he means to say another or something else.
    Faux pas: This type of mistake usually occurs when a person says something that he thinks harmless. But is actually has a meaning which upsets the speaker as well as the listeners.
    Mistranslation: This type of mistake is made when the text of a language is badly translated into another language.
    Spoonerism: This kind of mistake is made when a person mixes up the initial letters of the words he is speaking.

Quoting the mistakes because slip of tongue, the writer mentions that in a Royal Luncheon is Glasgow; a businessman wished Prince Charles a long and happy conjugal life with Lady Jane instead of Lady Diana. In Chicago, the governor of Illinois was introduced as mayor of Illinois and again as governor of America. While giving the examples of faux pas the writer mentions that once Nancy Regon describes the voters as ‘the beautiful white people’ ignoring the black people present there which put her in very difficult situation. The French prime minister while condemning a bomb attack once said that the bomb was aimed at Jews but it struck the innocent Frenchmen. It meant that the Jews in France weren’t Frenchmen and they weren’t innocent either. Mistranslation is also the cause of verbal error. Pepsi’s advertisement “Come alive with Pepsi” was mistranslated into German language as “Come alive out of the grave with Pepsi”. German prime minister once asked Indian president “Who are you?” instead of “How are you?” while receiving him at the airport.

Spoonerism began with William Archibald Spooner when he chided his students as “You hissed all my mystery lecture, you’ve tasted the whole worm........drain”. He meant to say as, “You’ve missed all my history lectures, you’ve wasted the whole term...down train”.

Although these mistakes are funny to us, linguists and psychologists take these mistakes seriously. Victoria Fromkin, a linguist calls the mistakes clues to how the brain stores and articulates language. Other linguists suggest that the mistake expresses the misspeaker’s inner thought. Psychologist Ludwig says the verbal mistake occurs because of human id, ego and super ego.


Verbal mistakes always tell us about the logic and possibility behind them. We always laugh when people make mistakes. Sometimes, we find mistakes funny because of being mean. But sometimes we laugh at verbal mistake because we feel sympathy as we all make mistakes.
