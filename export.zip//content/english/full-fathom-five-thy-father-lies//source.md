---
title:  Full Fathom Five Thy Father Lies - William Shakespeare 
slug: full-fathom-five-thy-father-lies
parent_slug: english
path: english/full-fathom-five-thy-father-lies/
---

 The poem "Full Fathom Five Thy Father Lies" is written by famous English poet and playwright (dramatist) William Shakespeare. This poem appears to be in Act-I, Scene-2 of his tragic comedy play The Tempest. Aerial sings this song to Ferdinand, the prince of Naples who mistakenly thinks that his father is drowned and arrives on the Solitary Island in search of his father.

Aerial says that the body of Ferdinand’s father keeps lying 30 ft. below in the sea. His bones are changed into precious corals and his eyes have been transformed into pearls. No part of his body has decayed but changed into something very strange and precious thing belonging to the sea. The sea nymphs are ringing the funeral bell every hour and morning the death of Ferdinand’s father.

Aerial consoles Ferdinand that even the death of his father becomes very meaningful because no part of his body is decayed rather changed into strange and very precious things of the sea. The poet in his poem expresses that death is the door step towards eternity which is an inevitable truth of life. Everyone has to confront (face) it, presenting the poem beautifully using various poetic devices, the poet expresses that even the death could be very meaningful it leads towards eternity and spiritual freedom.
Duke of Naples: King of an ancient state of Europe called Naples.

Ferdinand: Prince of Naples.

Aerial: A spirit in human form.
One fathom: Six feet

Thy: Your

Define the poetic devices used in the poem with examples.
The following are the poetic devices used in this poem.
a. Alliteration: It is the repetition of the initial sound of word many times in a sentence.
Example: Full Fathom Five thy Father lies
Here, the ‘F’ sound is repeated four times in the sentence.

b. Onomatopoeia: It is a way of expressing on object by imitating its sound instead of naming the object.
Example: Ding-dong-bell
Mew-cat

c. Assonance: It’s the process of making a vowel sound long and nasal to create special effect and to maintain the poetic matter.
Example: d-i-ng, d-o-ng

Write a brief account on ‘Art and Life’ or ‘Life and Art’.
The skill of creation is called Art. People in possession (having) of this creative skill are known as artist. Art may be different by its form, style and time. Although it is different by its form and style, art always influences human beings. Art always remains as an effective and important motivational factor for human beings. In order to live a happy and satisfied life, art is an inevitable aspect of life. An art in its supreme form is able to provide us the deepest inner freshness which in turn inspires us to make ourselves happy and amiable. To get rid of difficulties of life, it is immensely important for us to appreciate. By appreciating art, we can keep ourselves happy by forgetting the problems of life.

Human life is very transient (short) and when we die our life is finished. But despite this appearance of physical existence, an artist can live an immortal life. Life is sure to come to an end but art remains forever. Laxmi Prasad Devkota is remaining immortal among Nepali people for his fine piece of art in, literature in the form of Muna Madan. Other great artist’s of different artistic fields are still immortal because of their great works of art. When we enjoy art we find amiability within ourselves thereby inspiring us to appreciate art. It is indeed true that all works of art provide us the deepest experience and higher value of our life.
