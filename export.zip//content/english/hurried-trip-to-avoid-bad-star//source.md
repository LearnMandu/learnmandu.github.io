---
title: Hurried trip to avoid a Bad star - M. Lilla and C. Bishop Barry
slug: hurried-trip-to-avoid-bad-star
parent_slug: english
path: english/hurried-trip-to-avoid-bad-star/
---

American geographers M. Lilla and C. Bishop Barry in their essay Hurried trip to avoid a Bad Star present an exploration of Karnali zone of western Nepal on foot for 15 months. This essay was published as a visit report in The National Geographic as Karnali, The road less World of Western Nepal in 1971. The writers in this essay describe the life account of Karnali zone people, their daily life, their tradition and culture, their lack of awareness about environmental preservation and Karnali zone’s economic dependency with the plain region of south Nepal.

With a view to study above mentioned aspects, the writers move to plain of south Nepal with the peasants (farmers) who were going towards Nepalgunj for their daily provisions. They were carrying medicinal herbs, hand knitted sweaters and blankets etc. to sell in Nepalgunj.

While climbing step hill near Hari Lekh a Chhetri women of about 36 requested them to send her husband back home who left the house 15 years ago in search of job in the Terai. This request revealed the concept of Karnali zone people about parameter of the world. This may present some resemblance to a proverb popular among the Nepali people; something about a frog in a pond.

In a Sal forest slope the writers noticed the chopping down trees from several direction which indicated the possibility of rapid deforestation in the region. On inquiry, the people explained their compulsion to chop down the trees to feed their animals which exposed their lack of education and ignorance about the importance of preservation of environment. The writers noticed a group of 8 or 9 men in a forest processing Silajit in order to sell in Nepalgunj.These superstitious people, with whom the writers shared the trip, made a hurried trip from their home valley to avoid some kind of 'evil influence' of bad star.

On arrival in Nepalgunj the writers watched the hill people buying their daily provisions; one of them spent all his money buying distillery equipment with a hope to earn money by selling homemade  alcohol.

The writers finally concluded their journey at Jumla. They expressed their concern on lack of awareness on Karnali zone people about protection of nature and about the need of educating people regarding this vital aspect. They also expressed that Karnali zone people were living in very difficult place with a very low agricultural production and also suggested them to involve themselves in trade with the Terai region in order to make their life easy with satisfactory earning.

Give a short account of life of Karnali zone people.
Two American geographers have depicted (painted) and described the state and lifestyle of Karnali zone. The life of Karnali zone people is extremely hard because Karnali zone is a remote, not well connected with other parts of the country by road and economically backward.

Due to the lack of education the people of that region are very superstitious and believe that a bad star may have evil influence on them and try to avoid it. They are lacking the awareness about the need of preservation of nature. By speeding of the deforestation they are putting their own life’s inside a bottle of great risk because the entire slopes became bare and prone (possible) of landslide and soil erosion.

Although the people of this region are living in harmony with nature in very difficult location with very bad weather, they are not ready to leave their place. The writers found that a hill place is very optimistic and cheerful despite hardship in life with low harvest.

Many of the people in Karnali zone are involved in business. They carry their local products including Silajit to sell in Nepalgunj whenever they go down to the Terai. When they return home they bring necessary goods like aluminum and iron wares, cotton clothes, jewelry items and spices to sell in their locality to earn a living.

Altogether, the life for the native of Karnali is very difficult only when compared to the life in any other developed region of Nepal. But, when one spends much time and finally blends in with the day to day life of that place, it starts to look more natural way to live. The lost but not forgotten hope of that chettri woman can be taken as an inspiration to put up with emotional hardship of loosing any possible hope in their dreams.
