---
title:  My Heart Leaps up When I Behold - William Wordsworth 
slug: my-heart-leaps-up-when-i-behold
parent_slug: english
path: english/my-heart-leaps-up-when-i-behold/
---

 The poem “My heart Leaps up when I behold” is written by William Wordsworth and English poet and worshipper of nature and simplicity. The poem is based on the recollection of the poet’s childhood experience and feelings that bear the stamp of continuity.

The poem deals with the spontaneous overflow of those powerful feelings and joys as felt by the heart of the poet in his childhood and manhood at the sight of a rainbow in the sky and the poet hopes to feel the same in the old age.

The poet describes the influence of a rainbow upon his heart. According to his words, he feels the same joy and happiness when he was a child and he does feel the same experience in his old age. In the absence of such feelings, the poet admits he will prefer death as a better alternative. The poem ends with the wish of the poet for his days to be bound with each other by natural piety.

The poem consists of a well-known paradox “the child is father of the man”. It implies that as a child for the first time he felt the joy while looking at the nature in the form of a rainbow and every child does have some kind of experience before he attains manhood. In this regard he is senior to man and therefore the father of the man.
