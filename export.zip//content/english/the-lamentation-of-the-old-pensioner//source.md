---
title:  The Lamentation of the Old Pensioner - W.B Yeats 
slug: the-lamentation-of-the-old-pensioner
parent_slug: english
path: english/the-lamentation-of-the-old-pensioner/
---

 W.B Yeats in his poem The Lamentation of the Old Pensioner recollects his young and energetic youth and laments at his neglected state in his old age.

Understanding a long journey of life through ups and downs the poet feels tired, upset and heading a neglected life in his old age.  The poet in his old age now is companion less and protecting himself from the rain taking shelter under a broken tree. But in his young and colorful days in the past. The poet used to be surrounded by his friends discussing love and politics in such raining days. He was actively involved in politics and the political situation was calm and quiet during his time. He recollects the peaceful political situation of his time and contracts the present violent political situation where people are collecting weapons and making conspiracy to over through the government to get power however, the poet is different about present political situation who is mentally thinking about cruel time that has transfigured him from young to old depriving him from enjoying his colorful life.      

The poet in his old age now feels neglected and lonely and struggles with difficulties of life alone. However, the memory of his glorious past days when he used to be the point of attention and attraction to everybody is still very fresh in his mind. Although, he is physically weak, old and disfigured now, his memory is still interact which time is not being able to remove from his mind. The poet considers that the time is responsible for his present neglected condition. Therefore, the poet expresses his anger with the time by splitting into its face for changing him from young to old.
