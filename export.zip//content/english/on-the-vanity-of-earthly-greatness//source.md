---
title:  On The vanity of earthly greatness - Arthur Guiterman 
slug: on-the-vanity-of-earthly-greatness
parent_slug: english
path: english/on-the-vanity-of-earthly-greatness/
---

 "On the Vanity of Earthly Greatness" is a modern poem written by an American poet Arthur Guiterman. It is a flawless poem, which shows the remorselessness of time and the vanity of human greatness.

Through this poem, the poet announces his philosophy of life or outlook that all those entities that symbolize earthly grandeur, greatness and power such as the tusks of mastodons, the sword of Charlemagne the Just, the grizzly bear, great Caesar etc. will be reduced in course of time into things of non-entity.


The presentation of subject matter is quite ironical. Without using the negative words, the poet turns the things of earthly greatness into mere showpiece and nothingness. Each sentence is well balanced with splendid things in place of subject being linked up with worthless objects at the other end. Each sentence of the poem brings out the image of a balance, with a grand figure on the side and cipher on the other side. The irony is obvious when the readers notice the tusks transformed into billiard balls, the sword of Charlemagne into rust, the grizzly bear into rug etc.


One can trace out the sign of vanity in the last couple where the poet admits that he doesn’t feel so well himself in the presence of Great Caesar’s bust on the shelf. This implies that even the poet is not an exception because to some extent he also seems to suffer from vanity complex of greatness.
