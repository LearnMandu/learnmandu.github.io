---
title: BSc CSIT
slug: csit
parent_slug: 
path: csit/
---

Resources for BSc CSIT students. Work In Progress.
