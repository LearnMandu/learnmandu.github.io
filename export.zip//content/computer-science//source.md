---
title: Computer Science
slug: computer-science
parent_slug: 
path: computer-science/
---

Computer science is the study of the theory, experimentation, and engineering that form the basics for the design and use of computers.
[Wikipedia](https://en.wikipedia.org/wiki/Computer_science)

### Old Questions
[Computer Science, Grade XI - 2069 (2012)](http://www.4shared.com/office/fyYzag3i/Computer_Science_2069_XI.html)
