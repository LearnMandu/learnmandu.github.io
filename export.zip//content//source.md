---
title: Main
slug: 
parent_slug: 
path: 
---

This is the main page. We aim to be the ideal hub for Nepali students and teachers to learn and share.
