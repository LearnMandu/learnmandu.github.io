---
title:  Introduction To Biology 
slug: introduction
parent_slug: biology
path: biology/introduction/
---


1. Why water is important for our life?
Water is a major chemical of protoplasm which plays a major role in our life.

2. What do you mean by carbohydrate?
Carbohydrates are the organic compounds of carbon, hydrogen and oxygen, where the hydrogen and oxygen are present in the ration 2:1 as in water.

3. Give the name of different types of carbohydrates.
Carbohydrates are classified into monosaccharides, disaccharides and polysaccharides.
 

4. Why are chains of amino acids called peptides?
The amino acids are linked together with the help of peptide bonds and the chains of amino acids bonded by such linkages are termed peptides.

5. What is a peptide bond?
A covalent bond between a nitrogen atom and a carbon atom is called peptide bond.

6. What do you mean by protein?
The proteins are polymers of twenty different amino acids.

7. What are lipids?
Lipids are compound of C, H and O but have much less oxygen compared to carbohydrates. They are insoluble in water but readily dissolve in organic solvent such as ether, benzene and chloroform.

8. What are simple lipids?
Simple lipids are esters of fatty acids and various alcohols.

9. What are compound lipids?
Compound lipids contain other groups in addition to fatty acids and alcohol.

10. What are sterols?
Sterols are derived lipids formed of four carbon rings with a attached R group.

11. In which part of a plant are fats found in large amount?
Fats are abundantly found in seeds as reserve food with a large amount of energy stored in them.

12. What are enzymes?
Enzymes are biological catalysts which speed up or catalyze the metabolic reactions in the cells. 
Chemically all enzymes are proteins.

13. What are cofactors and coenzymes?
The cofactors and coenzymes are substances essential only for the functioning of enzymes. The term coenzyme is used for organic molecules, whereas the term cofactor is used for inorganic ions.

14. What are nucleic acids?
Nucleic acids are long chain macromolecules of nucleotides with high molecular weight. They are composed of a pentose sugar, phosphoric acid and nitrogen bases.

15. Write the structural difference found between DNA and RNA.
Structurally DNA and RNA show two main differences: (a) DNA contains deoxyribose sugar and RNA contains ribose sugar. (b) DNA contains thymine whereas the RNA contains uracil.

16. Who established the double helix structure of DNA?
Double helix structure of DNA was established by Watson and Crick (1953) on the basis of the x-ray diffraction.

17. What are the important life components?
The important life components are basically classified into two types and they are; (a) Organic compounds: Carbohydrates, lipids, proteins and nucleic acids. (b) Inorganic compounds: Water and minerals.

18. Name the components of nucleotide.
Each nucleotide is formed by cross-linking of three substances (a) pentose sugar (Deoxyribose or Ribose sugar) (b) phosphoric acid and (c) nitrogen bases (Purines – adenine and guanine & Pyrimidines – thymine, cytosine and uracil).

19. Name two DNA containing cell organells.
Mitrochondria and Chloroplast are the two DNA containing cell organells.

20. How do fats yield more energy than starch on oxidation?
On oxidation, fats yield more than twice energy as the oxidation of the same weight of starch, as fats have less oxygen.

21. What type of bonds hold a DNA double helix together?
The double helix of DNA is held together by hydrogen bonds between specific pairs of purines and pyrimidines.

22. What do you mean by nucleotides?
A sugar molecule with nitrogenous base and phosphate group forms a nucleotide.

23. Name the devices used to establish the structure of DNA.
The x-ray diffraction was used by Watson and Crick (1953) to establish the structure of DNA.

24. Why does not oil dissolve in water?
Oil is a hydrophobic non-polar group and cannot form hydrogen bond with water and therefore doesn’t dissolve in water.

25. Define cellular pool.
The collection of various types of molecules in a cell called cellular pool.

26. Name three main elements that constitute the major part of the cellular material.
Carbon, Hydrogen and Oxygen.

27. Name small molecules of the cell.
Minerals, water, amino acids, sugars, lipids and nucleotides.

28. Write the name of sugar which is found in the blood plasma of human beings.
Glucose.

29. What will be formed of hydrolysis of lactose sugar?
Glucose and glactose.

30. Name a nitrogen containing polysaccharide.
Chitin.

31. Give two examples of aldose sugars.
Glucose and ribose sugar.

32. Give two examples of ketose sugar.
Fructose and ribose sugar.

33. Which is the most common form of sugar in fruits?
Fructose.

34. Why cannot cellulose be digested by animals and human?
Due to lack of cellulose digestive enzyme in our digestive system, the cellulose cannot be digested.
