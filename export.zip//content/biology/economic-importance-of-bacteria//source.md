---
title:  Economic Importance of Bacteria 
slug: economic-importance-of-bacteria
parent_slug: biology
path: biology/economic-importance-of-bacteria/
---

 Bacteria play very important role in the continuous sustenance of life. They are man’s best friends as well as enemy. There are many useful as well as harmful bacteria around us. Economic importances of bacteria are studied under two headings they are Beneficial activities and Harmful activities. Beneficial Activities are studied under three headings
A)    Agricultural Importance
i)    Dead and decay of organic matter-saprophytic bacteria eg. Clostridium, Staphylo, Coccus, salmonella etc acts upon the organic matter and disintegrates them converting valuable fertilizer.
ii)    Nitrification:- It is a process of conversion of organic substance into nitrate form which are utilized by green plants easily. Eg Nitrifying bacteria like ammonia salts (nitrosomes and nitrococcus) to nitrites (nitrobacter) – Nitrates

iii)    Nitrogen fixation- in the air present 78% of nitrogen, but atmospheric nitrogen cannot be utilized by plants directly. The process of conversion of atmospheric nitrogen into molecular nitrogen by bacteria. Eg Rhizobium, Azobactor, Clostridium is called Nitrogen fixation.
iv)    Soil fertility- soil bacteria plays important role for the soil fertility. When soil will be fertile, automatically agricultural production will be increased. Eg- Fusarium and other soil bacteria.
v)    Manure- saprophytic bacteria acts on animal dung, farm refuse and organic wastage of industrial house resulting manure which is the best for agricultural production.
vi)    Ensilage
vii)    Gobar Gas Plant

B)    Industrial Importance
i)    Milk is converted into curd by the action lactic acid bacteria.
ii)    Cheese- Milk first coagulated by chemical reagent and converted into spongy, soft, tasty cheese.
iii)    Vinegar Production- Mycoderm bacteria converts sugar and sugary substance into acetic acid or vinegar.
iv)    Alcohol and acetone production.
Molases (Sugary substance)--------(fermentation/Clostriduim)---- Acetone + Alcohol
v)    Curing and ripening of tea and tobacco leaves- when harvested leaves and hung in shed, they will be acted by bacteria micrococcus resulting flavor and tasty.
vi)    Fibre retting- the intact firbres of jute, hemp, flax,etc are separated by bacterial action. Fibre plant when immersed in water acted by bacteria dissolves pactic substances of middle la,ella and yiekds fibres, which are used for many commercial uses e.g. Making different kinds of ropes bags,shoes etc
vii)    Leather tanning-bacteria are used to convert skin of animal (hide) into leather. Recently replaced by chemical for tanning.

C)    Medicinal importance
i) Vitamin B- Riboflavin obtained from clostridium
ii) Antibiotics-Different antibiotics are obtained from bacteria’s like Thyromicin antibiotic by bacillus brevis bacteria. Subtilin antibiotics obtained by bacillus substises.

Harmful Activities of Bacteria
About 90% of human and disease are caused by bacteria
1)     Animal Diseasei)    Cholera- Vibrio cholera
ii)    Tuberclosis- Mycobaterium tuberculosis
iii)    Leprosy- Mycobacterium leprae
iv)    Typhoid- Bacillus typhosus
v)    Tetanus- Clostridium tetani
vi)    Pneumania- Dilplococcus pnemoniae

Plant diseases caused by bacteria
i)    Citrus Canker- Xanthomonas citri
ii)    Leaf blight of rice- Xanthomonas oryzae
iii)    Bacteria blight of bean- Xanthomonas phaseoli
2)    Spoilage of food stuff- Sporophytic bacteria acts upon different food stuff resulting unfit for eating.
3)    Food poisoning- Some bacteria like Staphylococcus aureus secrets toxic substance due to which food becomes poisonous resulting even death too.
4)    Deterioration of Domestic articles- Wooden articles, fibres, leather deteriorate by action of bacteria eg (Spirochaete cytophaga)
5)    Denitrification and desulphurification of soil-plants can absorb NO3 and SO¬4 form of nitrogen and sulphur by the process of nitrification and sulphurificarion. But there are some harmful bacteria which convert NO3 and SO4 form of nitrogen and sulphur into NO2 and H2S which are not utilized. Hence, bacteria are our friend as well as enemy.
