---
title:  Cell Biology, Conceptual Questions with Answers 
slug: cell-biology
parent_slug: biology
path: biology/cell-biology/
---

 1. What is cell?
Cell is the basic structural and functional unit of living organism. It is the smallest unit, that can carry all the process of life.

2. Who discovered the cell?
In 1665 Robert Hooke studied the cell in a thin slice of cork for the first time.

3. Who gave the cell theory?
Schleiden and Schwann gave a cell theory which proposes that the bodies of animals and plants are composed of cells and products of cells.

4. How cell arise?
According to cell theory all cells arise from pre-existing cells.
5. What is protoplasm?
The semi-fluid mass of cytoplasm including nucleus is called protoplasm. Protoplasm with non-living inclusions, excluding cell wall is called protoplast.

6. What is cytoplasm?
The semi-fluid mass of the protoplasm excluding nucleus is called cytoplasm. Cell membrane forms the outer most covering of the cytoplasm, while nucleus forms the internal boundary.

7. Define nucleus.
Nucleus was first discovered by Robert Brown (1831) in an orchid cell. It is a dense protoplasmic body lying embedded in the cytoplasm. It directs and controls all the life activities of a cell.

8. How a plant cell differ from animal cell?
A plant cell differs from an animal cell in having cell wall, plastids a large central vacuole and by the absence of a centriole.

9. Define centrosome.
The chromosomes are defined as the coloured body of nucleus. They contain genes and hence carry the genetic information.

10. What do you mean by heterochromatin and euchromatin?
Each chromosome consists of two distinct regions: (i). Heterochromatin and (ii) Euchoromatin. Heterochromatin is genetically inactive, but it controls the metabolism of the chromosome, biosynthesis of the nucleic acid and the energy metabolism. The euchromatin is genetically active substance. It is rich in DNA and forms the major portion of chromosome.

11. What do you mean by prokaryotic cell?
A prokaryotic cell is relatively simple cell. It has an incipient nucleus, the genetic material is present as circular structure formed of DNA fibres only. It lacks all the membrane bound organells.

12. Name the longest plant cell.
Acetabularia
13. What do you mean by eukaryotic cell?

An eukaryotic cell has a membrane bound nucleus (an organized nucleus). The genetic material is present in the form chromosome. It contains a number of membrane bound organells.

14. What are cytoplasmic inclusions?
As a result of metabolic activities several kinds of non-living substances are produced within the cell, which are called cytoplasmic incusions or ergastic substances.

15. What is cell division?
Cell division is a process in which formation of new cells or increase in number of cells take place by the division of pre-existing cell.

16. How many methods of cell division are found?
In plant and animal, cells divide by three methods:
a. Amitosis or direct cell division.
b. Mitosis or indirect cell division.
c. Meiosis or reductional cell division.

17. What do you mean by cell cycle?
The total changes from one mitosis cell division to another mitosis cell division is called cell cycle.

18. What is mitosis cell division?
Mitosis is the division of the cell in which a single cell divides to form two cells, each having the same number of chromosomes as present in parent cell. It is also called somatic or vegetative cell division.

19. What is the importance of mitosis cell division?
Mitosis cell division is essential for the growth of plant and animal body. It helps to produce genetically identical cells.

20. What is meiosis cell division?
In meiosis cell division, a diploid cell divides to form four haploid cells, each having half the number of chromosomes present in the parent cell. It occurs in reproductive cells at the time of gametes or spores formation.

21. How many nuclear division are found in meiosis?
Meiosis comprises of two nuclear divisions;
a. Heterotypic or meiosis first or reductional division, and
b. Homotypic or meiosis second or equational division.

22. What are plasmodesmata?
The cell walls discontinued at some places forming pits are called plasmodesmata. They facilitate movement of substances between adjacent cells.

23. Name the biomolecules responsible for the two principle roles of nucleus.
a. DNA carries hereditary information.
b. RNA codes for the enzymes to be formed.

24. What is the function of nuclear pores?
Nuclear pores serve as pathways for exchange of macromolecules between nucleus and cytoplasm.

25. Where are elementary particles located?
The outer surface of outer membrane and inner surface of inner membrane or mitochondria contain numerous minute structures called elementary particles or oxysomes.

26. Enumerate the functions of cytoplasm.
a. Intracellular distribution of metabolites within the cell.
b. Exchange of material among different organells.
c. Provides site for glycolysis.

27. What are the functions of cytoskeleton?
a. Forms structural framework within the cell.
b. Maintains the shape of the cell.
c. Regulates distribution and orientation of organells.

28. Why is mitosis an equational division?
The mitosis is an equational division because the daughter cells have the same number of chromosomes and equal amount of cytoplasm.

29. Why is meiosis a reductional division?
In meiosis cell division the number of chromosomes become half, therefore it is a reductional division.

30. What is the region of attachment of chromosome to the spindle fibres called?
Centromere.

31. Define synapsis.
The pairing of homologous chromosomes during zygotene substage is called synapsis.

32. Define crossing over.
The exchange of small segment of chromosomes between homologus chromosomes is called crossing over.
