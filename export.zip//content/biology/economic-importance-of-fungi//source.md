---
title: Economic Importance of Fungi
slug: economic-importance-of-fungi
parent_slug: biology
path: biology/economic-importance-of-fungi/
---

Fungi have both positive ad negative roles in our daily life. So they are our friends as well as foes (enemy).

They are described as below.

**Beneficial Roles or Useful Activities**

1. Fungi are used as food. e.g. Mushrooms and Morels.
2. Fungi are used in laboratory.
    * Baking Yeast (S. cerevisae)
    * Several alcoholic beverages such as wine, whiskey, beer, rum all are prepared by fermentation activity of sugar solution by wine yeast. (S. ellipsoidens)
   * Some fungi are used in production of enzymes like amylase, pectimase
3. Some fungi are used in production of several antibiotics and antibiotics and other useful medicine like penicillin, streptomycin, ergotine and ephedrine respectively.
4. Several fungi are used in commercial production of different organic products like citric acid, fumaric, lactic and oxalic acid.
5. Fungi in agriculture:
   * Being saprophytes they decompose the organic matter and enhance the fertility of the soil.
   * Some fungi develop symbiotic relation with roots of higher plant like Pinus and help them in absorption of nutrients. Such fungi are known as mycorrhiza.
6. Some fungi are used to produce hormone like Gibberellin.


**Harmful Activities:**

1. Food spoilage (destruction) caused by fungi like mucor and yeast.
2. Some yeasts causes huge loss in silk industry to attack silk worms and kill the same.
3. Several types of plant diseases caused by (different types of fungi) species of Nematospra they attack tomatoes, cotton and bean plants. Similar disease like causal organisms
    * Stem rust of wheat – Pucvinia graministice
    * Early blight of potato – Alternaria solani
    * Late blight of potato – Phytiphtoria infestans
    * White rust of crucifer – Albugo candida
4. Some fungi (Cryptococcus neoformans) may cause human disease like meningitis and brain tumor. Torula and other yeasts produce small nodules on the skin and lesions in the viscera and bones of man.
5. Some fungi are concerned with destruction of substances like attacks textile materials, paper, leather goods, rubber even optical instruments.
6. Some fungi are not edible mushroom like different species Amanita.
