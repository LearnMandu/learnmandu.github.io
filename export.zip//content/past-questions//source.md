---
title: Old Questions
slug: past-questions
parent_slug: 
path: past-questions/
---

1. [Chemistry, Grade 11 - 2069 (2012)](http://www.scribd.com/doc/100293578/HSEB-Question-Collection-Series-Chemistry-2069-XI-HSEB-NOTES)

2. [Physics New Course Grade 11 - 2069 (2012)](http://www.scribd.com/doc/100293603/HSEB-Question-Collection-Series-Physics-New-Course-2069-XI-HSEB-NOTES)

3. [Computer Science, Grade XI - 2069 (2012)](http://www.4shared.com/office/fyYzag3i/Computer_Science_2069_XI.html)

4. [Biology, Grade XI - 2069 (2012)](http://www.4shared.com/office/CQ3BsNxD/Biology_2069_XI.html)

5. [Compulsory English, Grade XI, - 2069 (2012)](http://www.4shared.com/office/yU3xUL_d/HSEB_Question_Collection_Serie.html)

